package edu.utsa.tl09;

public class ParserError extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6928262596043702813L;

	public ParserError(String expected, Token look)
	{
		super(look.fileName + ":" + look.lineNumber + " Expected: " + expected + " Found: " + look);
	}

}

