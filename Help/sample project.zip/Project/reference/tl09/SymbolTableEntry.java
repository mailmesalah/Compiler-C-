package edu.utsa.tl09;

import java.util.ArrayList;

import edu.utsa.tl09.nodes.NodeType;

public class SymbolTableEntry {
	public String symbolName;
	public NodeType symbolType = NodeType.empty;
	public Token nameToken;
	public Token typeToken;
	public ArrayList<Token> refereneces = new ArrayList<Token>();
	int memoryAddress;
}

