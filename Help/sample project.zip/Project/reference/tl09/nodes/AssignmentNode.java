package edu.utsa.tl09.nodes;

import edu.utsa.tl09.*;
import edu.utsa.tl09.code.CodeGenerator;

/*
 * <assignment> ::= ident ASGN <expression>
 *      		|	ident ASGN READINT
 */
public class AssignmentNode extends StatementNode{

	public AssignmentNode() {		
		super(NodeType.assignment);
	}

	@Override
	public void annotate(SymbolTable table) {
		table.addReference(this.getAssignedVariable());

		if( this.isReadInt() )
		{
			this.setErrorOnFalse(this.getAssignedVariable().expectDataType(NodeType.INT));
		}
		else
		{
			this.getExpression().annotate(table);	
			
			this.setErrorOnFalse(this.getAssignedVariable().expectDataType(this.getExpression().nodeDataType));
		}
		
		this.checkChildrenError();
	}
	
	public Token getAssignedVariable()
	{
		return (Token)(this.children.get(0));
	}
	
	public Node getExpression()
	{
		return (Node)(this.children.get(2));
	}
	
	public boolean isReadInt()
	{
		return this.children.get(2) instanceof Token;
	}
	
	@Override
	protected boolean isAstVisible()
	{
		return true;
	}	
	
	@Override
	protected String getAstLabel()
	{
		if( this.isReadInt() )
		{
			return this.getChildren(1).toString() + " " + this.getChildren(2).toString();
		}
		
		return this.getChildren(1).toString();
	}
	
	public String toILOC(CodeGenerator generator)
	{
		return "assignment";
	}
	
	public String toILOC(CodeGenerator generator, String startWith, String endWith, boolean mustEndBlock)	{
		Debug.println(Debug.ILOC, "assgn current:" + generator.getCurrentBlockLabel() 
				+ " start:" + startWith + " end:" + endWith + " force:" + mustEndBlock);

		if( this.isReadInt() )
		{	
			String var = this.getAssignedVariable().getValue();
			String r1 = generator.getNextRegister();
			String r2 = generator.getNextRegister();
			
			if( endWith == null )
			{
				endWith = generator.getNextBlockLabel("_rinext");
			}
			
			generator.startBlock(startWith, "_ristart");
			generator.instruction("loadI", "@" + var, r1);
			generator.instruction("add", "Rarp", r1, r2);
			generator.instruction("readInt", r2);
			generator.instruction("jumpI", endWith);
			
			return endWith;
		}
		else
		{	
			String var = this.getAssignedVariable().getValue();
			String r1 = generator.getNextRegister();

			if( startWith != null )
			{
				generator.startBlock(startWith);
			}
			
			generator.instruction("loadI", "@" + var, r1);		 
		 	String r3 = this.getExpression().toILOC(generator);		 	
		 	generator.instruction("storeAO", r3, "Rarp", r1);
		 	
		 	if( mustEndBlock )
		 	{
				if( endWith == null )
				{
					endWith = generator.getNextBlockLabel("_asnext");
				}

				generator.instruction("jumpI", endWith);
				generator.endCurrentBlock();								
		 	}
		 	
		 	return endWith;
		}		
	}
	
}

