package edu.utsa.tl09.nodes;

public enum NodeType {
	NUMBER, 
	IDENT, 
	BOOLLIT,   
	LP,
	RP,
	ASGN,
	SC,
	OP2,
	OP3,
	OP4,
	IF,
	THEN,
	ELSE,
	BEGIN,
	END,
	WHILE,
	DO,
	PROGRAM,
	VAR,
	AS,
	INT,
	BOOL,
	WRITEINT,
	READINT,  
	
	EOF,
	/* The remaining are node types */
	
	program, 
	declarations, declaration,
	type, 
	statementSequence, statement, 
	assignment, ifStatement, whileStatement, writeInt, elseClause, 
	expression, simpleExpression, term, factor,
	empty,
	
	/* Extra marker types */
	Error,
	None,
	
	}

