package edu.utsa.tl09.nodes;

import edu.utsa.tl09.*;

/*
	<type> ::= INT | BOOL
*/
public class TypeNode extends Node{
	public TypeNode()
	{
		super(NodeType.type);
	}
	
	public Token getTypeToken() {
		return (Token)this.getChildren(0);
	}
}

