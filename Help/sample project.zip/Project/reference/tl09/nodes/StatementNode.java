package edu.utsa.tl09.nodes;

import edu.utsa.tl09.*;
import edu.utsa.tl09.code.CodeGenerator;

public class StatementNode extends Node {
	public StatementNode()
	{
		super(NodeType.statement);
	}
	
	protected StatementNode(NodeType type)
	{
		super(type);
	}

	@Override
	public void annotate(SymbolTable table) {
		this.getChildren(0).annotate(table);
		this.checkChildrenError();
	}
	
	public StatementNode getStatement()
	{
		return (StatementNode)this.getChildren(0);
	}
	
	/**
	 * Generates code blocks for the given parse tree.
	 * @param generator
	 * @param startWith If not null, the code block must start with this block label.
	 * @param endWith If not null, the code generated should use this as the start of next block.
	 * @param mustEndBlock If set, the block must closed. Only case this is 
	 * 		false if the next statement is assignment. Two assignments can 
	 * 		be merged to a single assignment.
	 * 
	 * @return The block label of the next block. May be null.
	 */
	public String toILOC(CodeGenerator generator, String startWith, String endWith, boolean mustEndBlock)	{
		return this.getStatement().toILOC(generator, startWith, endWith, mustEndBlock);
	}
	
	public boolean isAssigmentStatement()
	{
		switch(this.nodeType)
		{
		case statement:
			return this.getStatement().isAssigmentStatement();
		case assignment:
			return !((AssignmentNode)this).isReadInt();			
		default:
			return false;
		}
	}
}


