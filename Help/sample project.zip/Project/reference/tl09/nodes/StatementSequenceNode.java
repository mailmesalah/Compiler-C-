package edu.utsa.tl09.nodes;

import java.util.ArrayList;


import edu.utsa.tl09.*;
import edu.utsa.tl09.code.CodeGenerator;

public class StatementSequenceNode extends Node {
	public StatementSequenceNode()
	{
		super(NodeType.statementSequence);
	}
	
	public boolean isEmpty()
	{
		return this.children.size() == 1 && this.children.get(0) == Node.E;
	}

	@Override
	public void annotate(SymbolTable table) {
		if( !isEmpty() )
		{
			this.getChildren(0).annotate(table);
			this.getChildren(2).annotate(table);
			
			this.checkChildrenError();
		}		
	}
	@Override
	protected String getAstLabel()
	{
		return "stmt list";
	}
	
	@Override
	protected boolean isAstVisible()
	{
		return !this.isEmpty();
	}

	@Override
	protected ArrayList<StatementNode> getAstChildren()
	{
		if( this.isEmpty() )
		{
			return new ArrayList<StatementNode>();
		}
		
		ArrayList<StatementNode> list = ((StatementSequenceNode)this.getChildren(2)).getAstChildren();
		
		list.add(0, (StatementNode)this.getChildren(0));
		
		return list;
	}
	
	@Override
	protected String getAstAttributes()
	{
		if( this.isError() )
		{
			return "shape=none style=solid fontcolor=\"/x11/red\""; 
		}
		
		return "shape=none style=solid";		
	}	
	
	public String toILOC(CodeGenerator generator, String startWith, String endWith)
	{
		Debug.println(Debug.ILOC, "stmts current:" + generator.getCurrentBlockLabel() 
			+ " start:" + startWith + " end:" + endWith);
		ArrayList<StatementNode> statements = this.getAstChildren();		
		int size = statements.size();
		
		for( int i = 0; i < size ; i ++ )
		{
			StatementNode statement = statements.get(i);
			boolean mustEndBlock = true;
			
			if( i+1 < size && statements.get(i+1).isAssigmentStatement() )
			{
				mustEndBlock = false;
			}
			
			startWith = statement.toILOC(generator, startWith, (i==(size-1))?endWith:null, mustEndBlock);
		}
		
		if( size == 0 )
		{			
			Debug.println(Debug.ILOC, "empty statement sequence");
			startWith = (startWith != null)?startWith:generator.getNextBlockLabel("_stmts");
			endWith = (endWith != null)?endWith:generator.getNextBlockLabel("_stmtnext");
			generator.startBlock(startWith);
			generator.instruction("jumpI", endWith);
		}
		
		return endWith;
	}	
	
	public String toILOC(CodeGenerator generator)
	{
		String blockStart = generator.getNextBlockLabel();
		
		this.toILOC(generator, blockStart, Constant.Bexit);
		generator.startBlock(Constant.Bexit);
		return Constant.Bexit;
	}
}

