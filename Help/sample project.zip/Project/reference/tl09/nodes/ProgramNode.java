package edu.utsa.tl09.nodes;

import edu.utsa.tl09.*;

/*
 * <program> ::= PROGRAM ident <declarations> BEGIN <statementSequence> END
 */
public class ProgramNode extends Node {
	public ProgramNode()
	{
		super(NodeType.program);
	}

	public Token getProgramName()
	{
		return (Token)this.getChildren().get(1);
	}
	
	public DeclarationsNode getDeclarations()
	{
		return (DeclarationsNode)this.getChildren().get(2);
	}
	
	public StatementSequenceNode getStatementSequence()
	{
		return (StatementSequenceNode)this.getChildren().get(4);
	}

	@Override
	public void annotate(SymbolTable table) {
		this.getDeclarations().annotate(table);
		this.getStatementSequence().annotate(table);
		this.checkChildrenError();
	}
	
	@Override
	protected boolean isAstVisible()
	{
		return true;
	}
}

