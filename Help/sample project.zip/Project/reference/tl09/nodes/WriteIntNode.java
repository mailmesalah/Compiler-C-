package edu.utsa.tl09.nodes;

import edu.utsa.tl09.*;
import edu.utsa.tl09.code.CodeGenerator;

/*
 * <writeInt> ::= WRITEINT <expression>
 */
public class WriteIntNode extends StatementNode {

	public WriteIntNode() {
		super(NodeType.writeInt);
	}

	public Node getExpression()
	{
		return this.getChildren(1);
	}
	
	@Override
	public void annotate(SymbolTable table) {
		this.getExpression().annotate(table);
		
		this.setErrorOnFalse(this.getExpression().expectDataType(NodeType.INT));
		this.checkChildrenError();
	}
	
	@Override
	protected boolean isAstVisible()
	{
		return true;
	}	
	
	@Override
	protected String getAstLabel()
	{
		return this.getChildren(0).toString();
	}

	public String toILOC(CodeGenerator generator) {
		return "writeInt";
	}
	
	public String toILOC(CodeGenerator generator, String startBlock, String endWith, boolean mustEndBlock)	{
		generator.startBlock(startBlock, "_wrstart");
		
		endWith = (endWith != null)?endWith:generator.getNextBlockLabel("_wrnext"); 

		String reg = this.getExpression().toILOC(generator);
		generator.instruction("writeInt", reg);
		generator.instruction("jumpI", endWith);
		
		return endWith;
	}
}

