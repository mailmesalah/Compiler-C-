package edu.utsa.tl09.nodes;

import edu.utsa.tl09.SymbolTable;
import edu.utsa.tl09.code.CodeGenerator;

/*
 * <elseClause> ::= ELSE <statementSequence>
 * 		| e
 */
public class ElseClauseNode extends Node{

	public ElseClauseNode() {
		super(NodeType.elseClause);
	}
	
	
	
	public boolean isEmpty()
	{
		return this.children.size() == 1 && this.children.get(0) == Node.E;
	}

	public StatementSequenceNode getElseStatements()
	{
		return (StatementSequenceNode)this.getChildren().get(1);
	}

	@Override
	public void annotate(SymbolTable table) {
		if( isEmpty() )
		{
			return;
		}
		
		this.getChildren().get(1).annotate(table);		
		this.checkChildrenError();
	}
		
	public String toILOC(CodeGenerator generator, String startWith, String endWith)
	{
		return this.getElseStatements().toILOC(generator, startWith, endWith);
	}		
}

