package edu.utsa.tl09.nodes;

import edu.utsa.tl09.*;
import edu.utsa.tl09.code.CodeGenerator;

/*
 * <whileStatement> ::= WHILE <expression> DO <statementSequence> END
 */
public class WhileStatementNode extends StatementNode {

	public WhileStatementNode() {
		super(NodeType.whileStatement);
	}

	public ExpressionNode getCondition()
	{
		return (ExpressionNode)this.getChildren(1);
	}
	
	public StatementSequenceNode getStatementSequence()
	{
		return (StatementSequenceNode)this.getChildren(3);
	}

	@Override
	public void annotate(SymbolTable table) {
		this.getCondition().annotate(table);
		this.setErrorOnFalse(this.getCondition().expectDataType(NodeType.BOOL));
		
		this.getStatementSequence().annotate(table);		
		
		this.checkChildrenError();
	}
	
	@Override
	protected boolean isAstVisible()
	{
		return true;
	}	
	
	@Override
	protected String getAstLabel()
	{
		return this.getChildren(0).toString();
	}
	

	public String toILOC(CodeGenerator generator, String startWith, String endWith, boolean mustEndBlock)
	{
		Debug.println(Debug.ILOC, "while current:" + generator.getCurrentBlockLabel() 
				+ " start:" + startWith + " end:" + endWith);

		startWith = generator.startBlock(startWith, "_whcond");
			
		String regCondition = this.getCondition().toILOC(generator);
		String blockStmts = generator.getNextBlockLabel("_wlstmt");
		
		endWith = (endWith != null)?endWith:generator.getNextBlockLabel("_whnext");

		generator.instruction("cbr", regCondition, blockStmts, endWith);			
				
		this.getStatementSequence().toILOC(generator, blockStmts, startWith);
		
		return endWith;
	}	
}

