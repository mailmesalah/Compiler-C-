package edu.utsa.tl09.nodes;

import edu.utsa.tl09.*;
import edu.utsa.tl09.code.CodeGenerator;
/*
 * <simpleExpression> ::= <term> OP3 <term>
 *             | <term>
 * OP3 = "+" | "-"
 */
public class SimpleExpressionNode extends Node {

	public SimpleExpressionNode() {
		super(NodeType.simpleExpression);
	}
	

	@Override
	public void annotate(SymbolTable table) {
		this.getChildren(0).annotate(table);
		
		if( this.getChildren().size() == 3 )
		{
			this.getChildren(2).annotate(table);
			this.setErrorOnFalse(this.getChildren(0).expectDataType( NodeType.INT));
			this.setErrorOnFalse(this.getChildren(2).expectDataType( NodeType.INT));
			
			if( !this.isError() )
			{
				this.nodeDataType = NodeType.INT;
			}
		}
		else
		{
			this.nodeDataType = this.getChildren(0).nodeDataType;
		}
		
		this.checkChildrenError();
	}
	
	public TermNode getLeftChildren()
	{
		return (TermNode)this.getChildren(0);
	}
	
	public TermNode getRightChildren()
	{
		return (TermNode)this.getChildren(2);
	}
	
	public Token getOperator()
	{
		return (Token)this.getChildren(1);
	}
	
	@Override
	protected boolean isAstVisible()
	{
		return this.getChildren().size() == 3;
	}	

	@Override
	protected String getAstLabel()
	{
		return this.getChildren(1).toString();
	}
	
	public String toILOC(CodeGenerator generator)
	{
		if( !this.isAstVisible() )
		{
			return this.getLeftChildren().toILOC(generator);
		}		
		
		String r1 = this.getLeftChildren().toILOC(generator);
		String r2 = this.getRightChildren().toILOC(generator);		
		String r3 = generator.getNextRegister();
		String op = "op3";
		
		String s = this.getOperator().getValue();

		// OP3 = "+" | "-"
		if( "+".equals(s) )
		{
			op = "add";			
		}
		else if( "-".equals(s) ) 
		{
			op = "sub";
		}
		
		generator.instruction(op, r1, r2, r3);

		return r3;
	}	
	
}

