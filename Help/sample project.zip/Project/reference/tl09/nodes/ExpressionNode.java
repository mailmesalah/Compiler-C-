package edu.utsa.tl09.nodes;

import edu.utsa.tl09.*;
import edu.utsa.tl09.code.CodeGenerator;

/*
 * <expression> ::= <simpleExpression>
 *        | <simpleExpression> OP4 <simpleExpression>
 * 	OP4 = "==" | "!=" | "<" | ">" | "<=" | ">="         
 */
public class ExpressionNode extends Node{
	public ExpressionNode(){
		super(NodeType.expression);
	}

	@Override
	public void annotate(SymbolTable table) {
		this.getLeftChildren().annotate(table);
		
		if( this.getChildren().size() == 3 )
		{
			this.getRightChildren().annotate(table);
			
			// Comparison operator OP4 expects both operand to be same. 
			this.setErrorOnFalse(this.getChildren(2).expectDataType( this.getChildren(0).nodeDataType));
			
			if( !this.isError() )
			{
				this.nodeDataType = NodeType.BOOL;
			}
		}
		else
		{
			this.nodeDataType = this.getLeftChildren().nodeDataType;
		}
		
		this.checkChildrenError();
	}
	
	public SimpleExpressionNode getLeftChildren()
	{
		return (SimpleExpressionNode)this.getChildren(0);
	}
	
	public SimpleExpressionNode getRightChildren()
	{
		return (SimpleExpressionNode)this.getChildren(2);
	}
	
	public Token getOperator()
	{
		return (Token)this.getChildren(1);
	}
	
	@Override
	protected boolean isAstVisible()
	{
		return this.getChildren().size() == 3;
	}	

	@Override
	protected String getAstLabel()
	{
		return this.getChildren(1).toString();
	}
	
	public String toILOC(CodeGenerator generator)
	{
		if( !this.isAstVisible() )
		{
			return this.getLeftChildren().toILOC(generator);
		}		
		
		String r1 = this.getLeftChildren().toILOC(generator);
		String r2 = this.getRightChildren().toILOC(generator);		
		String r3 = generator.getNextRegister();
		String op = "op4";
		
		String s = this.getOperator().getValue();
		//  "==" | "!=" | "<" | ">" | "<=" | ">="  
		if( "==".equals(s) )
		{
			op = "cmp";			
		}
		else if( "!=".equals(s) ) 
		{
			op = "cmp_NE";
		}
		else if( "<".equals(s) ) 
		{
			op = "cmp_LT";
		}
		else if( ">".equals(s) ) 
		{
			op = "cmp_GT";
		}
		else if( "<=".equals(s) ) 
		{
			op = "cmp_LE";
		}
		else if( ">=".equals(s) ) 
		{
			op = "cmp_GE";
		}
		
		generator.instruction(op, r1, r2, r3);

		return r3;
	}	
}

