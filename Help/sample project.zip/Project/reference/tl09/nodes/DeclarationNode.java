package edu.utsa.tl09.nodes;

import edu.utsa.tl09.*;
/*
<declaration> ::= VAR ident AS <type> 
*/
public class DeclarationNode extends Node {
	public DeclarationNode()
	{
		super(NodeType.declaration);
	}

	@Override
	public void annotate(SymbolTable table) {
		this.setErrorOnFalse(table.declare(this.getVariableName(), this.getVariableType().getTypeToken()));
	}
	
	public Token getVariableName()
	{
		return ((Token)(this.children.get(1)));
	}
	
	public TypeNode getVariableType()
	{	
		return (TypeNode)this.children.get(3);	
	}
	
	@Override
	protected boolean isAstVisible()
	{
		return true;
	}
	
	@Override
	protected String getAstLabel()
	{
		return "var decl";
	}	
}

