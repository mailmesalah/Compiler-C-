package edu.utsa.tl09.nodes;

import edu.utsa.tl09.*;
import edu.utsa.tl09.code.CodeGenerator;
/*
 * <ifStatement> ::= IF <expression> THEN <statementSequence> <elseClause> END
 */
public class IfStatementNode extends StatementNode {

	public IfStatementNode() {
		super(NodeType.ifStatement);
	}
	
	public Node getCondition()
	{
		return (Node)this.getChildren().get(1);
	}
	
	public StatementSequenceNode getIfStatements()
	{
		return (StatementSequenceNode)this.getChildren().get(3);
	}
	
	public ElseClauseNode getElseClause()
	{
		return (ElseClauseNode)this.getChildren().get(4);
	}
	
	public boolean hasElseClause()
	{
		return !this.getElseClause().isEmpty();
	}
	
	public StatementSequenceNode getElseStatements()
	{
		return this.getElseClause().getElseStatements();
	}

	public void annotate(SymbolTable table) {
		this.getCondition().annotate(table);
		
		this.setErrorOnFalse(this.getCondition().expectDataType(NodeType.BOOL));
		
		this.getIfStatements().annotate(table);
		this.getElseClause().annotate(table);
		
		this.checkChildrenError();
	}
	
	
	@Override
	protected boolean isAstVisible()
	{
		return true;
	}
	
	@Override
	protected String getAstLabel()
	{
		return this.getChildren(0).toString();
	}	
	
	public String toILOC(CodeGenerator generator, String startWith, String endWith, boolean mustEndBlock)
	{
		generator.startBlock(startWith, "_ifcond");
		
		// String statementStart = generator.startBlockIfNeeded("_ifcond");
		// generator.instruction("jumpI", statementStart);
		// generator.startBlock(statementStart);
		
		String regCondition = this.getCondition().toILOC(generator);

		if( this.hasElseClause() )
		{
			String blockIf = generator.getNextBlockLabel("_ifstmt") ;
			String blockElse = generator.getNextBlockLabel("_elstmt") ;
			
			endWith = (endWith != null)?endWith:generator.getNextBlockLabel("_ifnext");
			
			generator.instruction("cbr", regCondition, blockIf, blockElse);
			generator.endCurrentBlock();
			
			generator.startBlock(blockIf);			
			endWith = this.getIfStatements().toILOC(generator, blockIf, endWith);
			// generator.startBlockIfNeeded("_")
			// generator.instruction("jumpI", endWith);
			generator.endCurrentBlock();
			
			generator.startBlock(blockElse);			
			this.getElseStatements().toILOC(generator, blockElse, endWith);			
			// generator.instruction("jumpI", endWith);
			generator.endCurrentBlock();
		}
		else
		{
			String blockIf = generator.getNextBlockLabel("_ifstmt") ;			
			
			endWith = (endWith != null)?endWith:generator.getNextBlockLabel("_ifnext");
			
			generator.instruction("cbr", regCondition, blockIf, endWith);			
			
			generator.startBlock(blockIf);
			this.getIfStatements().toILOC(generator, blockIf, endWith);
		}
		
		return endWith;
	}
}

