package edu.utsa.tl09.nodes;

import edu.utsa.tl09.*;
import edu.utsa.tl09.code.CodeGenerator;

/*
 * <factor> ::= ident
     | num
     | boollit
     | LP <expression> RP

 */
public class FactorNode extends Node {

	public FactorNode() {
		super(NodeType.factor);
	}
	
	@Override
	public void annotate(SymbolTable table) {
		Token first = (Token)this.getChildren().get(0);
		switch(first.getType())
		{
		case IDENT:
			table.addReference(first);
			this.nodeDataType = first.nodeDataType;
			return;
			
		case NUMBER:
			this.nodeDataType = first.nodeDataType;
			return;
			
		case BOOLLIT:
			this.nodeDataType = first.nodeDataType;
			return;
			
		case LP:
			this.getChildren().get(1).annotate(table);
			this.nodeDataType = this.getChildren().get(1).nodeDataType;
			this.checkChildrenError();
			return;
		}
	}
	
	/**
	 * Emits code to load the given identifier, integer or boolean value.
	 * 
	 * Returns the register where it is loaded.
	 */
	public String toILOC(CodeGenerator generator)
	{
		Token first = (Token)this.getChildren().get(0);


		if( first.getType() == NodeType.LP )
			return this.getChildren(1).toILOC(generator);
		
		String target = first.getValue();
		
		if( first.getType() == NodeType.IDENT )
		{
			String r1 = generator.getNextRegister();
			generator.instruction("loadI", "@" + target, r1);
			String r2 = generator.getNextRegister();
			generator.instruction("loadAO", "Rarp", r1, r2);

			return r2;
		}
		
		String reg = generator.getNextRegister();		

		switch(first.getType())
		{				
		case NUMBER:
			generator.instruction("loadI", target, reg);
			break;
			
		case BOOLLIT:
			generator.instruction("loadI", first.getBoolValue()?"1":"0", reg);
			break;
			
		default:
			System.err.println("Error: Unknown type of Factor");
		}		
		
		return reg;
	}	
	
}

