package edu.utsa.tl09;

import java.io.IOException;


import edu.utsa.tl09.code.AssemblyGenerator;
import edu.utsa.tl09.code.CodeGenerator;
import edu.utsa.tl09.nodes.Node;

public class Compiler {
	
	
	public static final String TL09 = "tl09";
	public static final String PTDOT = "pt.dot";
	public static final String ASTDOT = "ast.dot";
	public static final String CFGDOT = "cfg.dot";
	public static final String S = "s";

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws Exception {
		if( args.length == 1 )
		{
			String fileName = args[0];
			String outFileName;
			Node node = null;
			
			try {
				node = new Parser(args[0]).parse();
				outFileName = fileName.replaceAll(TL09, PTDOT);
				Parser.toDotFile(outFileName, node);
				SymbolTable table = new SymbolTable(node);
				table.create();
				outFileName = fileName.replaceAll(TL09, ASTDOT);
				Parser.toAstFile(outFileName, node);
				
				CodeGenerator gen = new CodeGenerator(node, table);
				gen.generate();
				outFileName = fileName.replaceAll(TL09, CFGDOT);
				gen.toCfgGraph(outFileName);
				
				AssemblyGenerator ag = new AssemblyGenerator(table, gen.getBlocks(), gen.getRegisterNumber());
				outFileName = fileName.replaceAll(TL09, S);
				ag.toAssembly(outFileName);
				
			} catch(IOException ex)
			{
				System.err.println(ex.getMessage());				
			}
			catch( ParserError pe)
			{
				System.err.println("PARSER  ERROR " + pe.getMessage());
			}
			catch(Exception e)
			{
				e.printStackTrace();

			}
			finally
			{

			}
		}
	}
}





