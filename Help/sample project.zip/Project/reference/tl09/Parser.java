package edu.utsa.tl09;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import edu.utsa.tl09.nodes.*;

public class Parser {
	private Scanner scanner;
	
	public Parser(String fileName)
	{
		this.scanner = new Scanner(fileName);		
	}
	
	Token match(NodeType type)
	{
		Token t = this.scanner.get();
		
		if( t.getType() != type )
		{
			throw new ParserError(type.toString(), t);
		}
		
		// System.out.println("Match: " + t);
		
		return t;
	}
	
	public Node parse() throws IOException
	{
		this.scanner.scan();

		return this.parseProgram();		
	}
	
	/*
	 * <program> ::= PROGRAM ident <declarations> BEGIN <statementSequence> END
	 */
	Node parseProgram()
	{
		Node node = new ProgramNode();
		
		node.addToken(this.match(NodeType.PROGRAM));
		node.addToken(this.match(NodeType.IDENT));
		node.addNode(this.parseDeclarations());
		node.addToken(this.match(NodeType.BEGIN));
		node.addNode(this.parseStatementSequence());
		node.addToken(this.match(NodeType.END));
		this.match(NodeType.EOF);
		
		return node;
	}

	/*
		<declaration> ::= VAR ident AS <type> 
	 */
	Node parseDeclaration()
	{
		Node node = new DeclarationNode();
		
		node.addToken(this.match(NodeType.VAR));
		node.addToken(this.match(NodeType.IDENT));
		node.addToken(this.match(NodeType.AS));
		node.addNode(this.parseType());
		
		return node;	
	}

	/*
		<declarations> ::= <declaration> SC <declarations>
               | e

	 */
	Node parseDeclarations()
	{
		Node node = new DeclarationsNode();
		
		if(this.scanner.look().getType() == NodeType.VAR)
		{
			node.addNode(this.parseDeclaration());
			node.addToken(this.match(NodeType.SC));
			node.addNode(this.parseDeclarations());
		}
		else
		{
			node.addNode(Node.E);
		}
		
		return node;	
	}
	
	/*
 		<type> ::= INT | BOOL
	 */
	Node parseType()
	{
		Node node = new TypeNode();
		
		if( this.scanner.lookType() == NodeType.BOOL )
		{
			node.addToken(this.match(NodeType.BOOL));
		}
		else if( this.scanner.lookType() == NodeType.INT )
		{
			node.addToken(this.match(NodeType.INT));
		}
		else
		{
			throw new ParserError("type", this.scanner.look());
		}
		
		return node;
	}
	
	Node parseStatementSequence()
	{
		Node node = new StatementSequenceNode();
		
		if( !this.scanner.isLookType(NodeType.END)
				&& !this.scanner.isLookType(NodeType.ELSE)
				&& !this.scanner.isLookType(NodeType.EOF))
		{
			node.addNode(this.parseStatement());
			node.addToken(this.match(NodeType.SC));
			node.addNode(this.parseStatementSequence());
		}
		else
		{
			node.addNode(Node.E);
		}
		
		return node;
	}
	
	Node parseStatement()
	{
		Node node = new StatementNode();
		
		if( this.scanner.isLookType(NodeType.IF))
		{
			node.addNode(this.parseIfStatement());
		}
		else if ( this.scanner.isLookType(NodeType.WHILE))
		{
			node.addNode(this.parseWhileStatement());
		}
		else if( this.scanner.isLookType(NodeType.WRITEINT))
		{
			node.addNode(this.parseWriteInt());
		}
		else if( this.scanner.isLookType(NodeType.IDENT))
		{
			node.addNode(this.parseAssignment());
		}
		else 
		{
			throw new ParserError("Statement(IF|WHILE|READINT|IDENT)", this.scanner.look());
		}
		
		return node;
	}

	/*
	 * <ifStatement> ::= IF <expression> THEN <statementSequence> <elseClause> END
	 */
	Node parseIfStatement()
	{
		
		Node node = new IfStatementNode();
		//System.out.println("IfStatement");
		node.addToken(this.match(NodeType.IF));
		node.addNode(this.parseExpression());
		node.addToken(this.match(NodeType.THEN));
		node.addNode(this.parseStatementSequence());
		node.addNode(this.parseElseClause());
		node.addToken(this.match(NodeType.END));

		return node;
	}
	
	/*
	 * <whileStatement> ::= WHILE <expression> DO <statementSequence> END
	 */
	Node parseWhileStatement()
	{
		Node node = new WhileStatementNode();
		
		node.addToken(this.match(NodeType.WHILE));
		node.addNode(this.parseExpression());
		node.addToken(this.match(NodeType.DO));
		node.addNode(this.parseStatementSequence());
		node.addToken(this.match(NodeType.END));

		return node;
	}

	/*
	 * <writeInt> ::= WRITEINT <expression>
	 */
	Node parseWriteInt()
	{
		Node node = new WriteIntNode();
		
		node.addToken(this.match(NodeType.WRITEINT));
		node.addNode(this.parseExpression());

		return node;
	}
	
	/*
	 * <assignment> ::= ident ASGN <expression>
            | ident ASGN READINT
	 */
	Node parseAssignment()
	{
		Node node = new AssignmentNode();
		
		node.addToken(this.match(NodeType.IDENT));
		node.addToken(this.match(NodeType.ASGN));
		if( this.scanner.isLookType(NodeType.READINT))
		{
			node.addToken(this.match(NodeType.READINT));
		}
		else
		{
			node.addNode(this.parseExpression());
		}
		
		return node;
	}	

	/*
	 * <elseClause> ::= ELSE <statementSequence>
	 * 		| e
	 */
	Node parseElseClause()
	{
		Node node = new ElseClauseNode();
	
		if( this.scanner.isLookType(NodeType.ELSE))
		{
			node.addToken(this.match(NodeType.ELSE));
			node.addNode(this.parseStatementSequence());
		}
		else
		{
			node.addNode(Node.E);
		}
		
		return node;
	}


	/*
	 * <expression> ::= <simpleExpression>
             | <simpleExpression> OP4 <simpleExpression>
	 */
	Node parseExpression()
	{
		// System.out.println("expression: " + this.scanner.look());
		Node node = new ExpressionNode();
		
		node.addNode(this.parseSimpleExpression());
		
		if( this.scanner.isLookType(NodeType.OP4))
		{
			node.addToken(this.match(NodeType.OP4));
			node.addNode(this.parseSimpleExpression());
		}
		
		return node;
	}	
	
	/*
	 * <simpleExpression> ::= <term> OP3 <term>
                   | <term>
	 */
	Node parseSimpleExpression()
	{
		// System.out.println("simpleExpression: " + this.scanner.look());
		Node node = new SimpleExpressionNode();
		
		node.addNode(this.parseTerm());
		
		if( this.scanner.isLookType(NodeType.OP3))
		{
			node.addToken(this.match(NodeType.OP3));
			node.addNode(this.parseTerm());
		}
		
		return node;
	}	
	
	
	/*
	 * <term> ::= <factor> OP2 <factor>
       | <factor>
	 */
	Node parseTerm()
	{
		// System.out.println("term: " + this.scanner.look());
		Node node = new TermNode();
		
		node.addNode(this.parseFactor());
		
		if( this.scanner.isLookType(NodeType.OP2))
		{
			node.addToken(this.match(NodeType.OP2));
			node.addNode(this.parseFactor());
		}
		
		return node;
	}	
	
	/*
	 * <factor> ::= ident
         | num
         | boollit
         | LP <expression> RP

	 */
	Node parseFactor()
	{
		Node node = new FactorNode();
		
		if( this.scanner.isLookType(NodeType.LP))
		{
			node.addToken(this.match(NodeType.LP));
			node.addNode(this.parseExpression());
			node.addToken(this.match(NodeType.RP));
		}
		else if( this.scanner.isLookType(NodeType.BOOLLIT))
		{
			node.addToken(this.match(NodeType.BOOLLIT));
		}
		else if( this.scanner.isLookType(NodeType.IDENT))
		{
			node.addToken(this.match(NodeType.IDENT));
		}
		else if( this.scanner.isLookType(NodeType.NUMBER))
		{
			node.addToken(this.match(NodeType.NUMBER));
		}
		else 
		{
			throw new ParserError("Factor(LP|IDENT|NUM|BOOLLIT)", this.scanner.look());
		}
		
		return node;
	}
	
	public static void toDotFile(String fileName, Node node) throws IOException
	{
		PrintStream stream = new PrintStream(new FileOutputStream(fileName));
		
		stream.println("digraph tl07 {");
		stream.println("\tordering=out;");
		stream.println("\tnode [shape = box];");
		
		node.toDot(stream, Integer.MIN_VALUE, 1);
		
		stream.println("}");
	}
	
	public static void toAstFile(String fileName, Node node) throws IOException
	{
		PrintStream stream = new PrintStream(new FileOutputStream(fileName));
		
		stream.println("digraph tl07 {");
		stream.println("\tordering=out;");
		stream.println("\tnode [shape=box style=filled];");
		stream.println("\tnode [colorscheme=\"pastel13\" fillcolor = \"/x11/lightgrey\"];");

		node.toAst(stream, Integer.MIN_VALUE, 1);
		
		stream.println("}");
	}	
}

