package edu.utsa.tl09;

public class Constant {
	public static final String Bexit = "Bexit"; 
}

