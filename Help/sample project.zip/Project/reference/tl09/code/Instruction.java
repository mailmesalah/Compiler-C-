package edu.utsa.tl09.code;

import java.util.ArrayList;

public class Instruction {
	public static final String separator = " ";
	public String code ;
	public String op1;
	public String op2;
	public String op3;
	public int number;
	
	public Instruction(String code)
	{
		this.code = code;
		
		System.out.println(this);
	}
	
	public Instruction(String code, String op1, String op2, String op3)
	{
		this.code = code;
		this.op1 = op1;
		this.op2 = op2;
		this.op3 = op3;
	}

	public Instruction(String code, String op1, String op3)
	{
		this.code = code;
		this.op1 = op1;
		this.op2 = null;
		this.op3 = op3;
	}
	
	public Instruction(String code, String op3)
	{
		this.code = code;
		this.op1 = null;
		this.op2 = null;
		this.op3 = op3;
	}
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder();

		sb.append(this.code);
		sb.append(" ");
		sb.append(separator);
		if( this.op1 != null )
		{
			sb.append(this.op1);
		}
			
		if( this.op2 != null )
		{
			sb.append(", ");
			sb.append(this.op2);
		}
		if ( "jumpI".equalsIgnoreCase(this.code) )
		{
		}
		else if( "cbr".equalsIgnoreCase(this.code) )
		{
			sb.append(", "); 	
		}
		else if( this.op1 != null || this.op2 != null )
		{
			sb.append(" => ");
		}
		
		sb.append(this.op3);
		return sb.toString();
		/*
		return 
			pad(this.code) + separator + 
			pad(this.op1) + ((this.op2 == null)?"  ":", ") +   
			pad(this.op2) + ((this.op1 == null&&this.op2==null)?"   ":"=> ") +
			pad(this.op3);
		*/
	}
	
	public String pad(String s)
	{
		return pad(s, 10);
	}
	
	private String pad(String s, int l)
	{
		if( s == null )
		{
			s = "";
		}
		
		StringBuilder sb = new StringBuilder(s);
		
		while( sb.length() < l )
		{
			sb.append(' ');
		}
		
		return sb.toString();
	}

	public ArrayList<String> getOutBlocks() {
		ArrayList<String> list = new ArrayList<String>();
		
		if ( "jumpI".equalsIgnoreCase(this.code) )
		{
			list.add(this.op3); 	
		}
		else if( "cbr".equalsIgnoreCase(this.code) )
		{
			list.add(this.op3); 	
			list.add(this.op2);
		}
		
		return list;
	}
	
	public boolean isOffset()
	{
		return this.op1.startsWith("@");
	}
	
	public String getVarOp1()
	{
		return this.op1.replaceFirst("@", "");
	}
	
	public boolean isConstantOp1()
	{
		try { 
			Integer.parseInt(this.op1);
			
			return true;
		} catch( NumberFormatException nfe )
		{
			return false;
		}		
	}

	public boolean isBinaryOperator() 
	{
		return "cmp" . equalsIgnoreCase(this.code) 
			|| "cmp_LE" . equalsIgnoreCase(this.code) 
			|| "cmp_GE" . equalsIgnoreCase(this.code) 
			|| "cmp_GT" . equalsIgnoreCase(this.code)
			|| "cmp_LT" . equalsIgnoreCase(this.code) 
			|| "cmp_NE" . equalsIgnoreCase(this.code)
			|| "add" . equalsIgnoreCase(this.code) 
			|| "sub" . equalsIgnoreCase(this.code)
			|| "mult" . equalsIgnoreCase(this.code)
			// || "div" . equalsIgnoreCase(this.code)
			;
	}
	
}

