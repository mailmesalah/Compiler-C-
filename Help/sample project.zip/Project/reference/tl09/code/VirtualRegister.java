package edu.utsa.tl09.code;

public class VirtualRegister {
	int number;
	String name;
	ContentType contentType = ContentType.Empty;
	int offset;	
	String address;
	
	public static VirtualRegister Rarp = new VirtualRegister("Rarp", "$fp");
	
	private VirtualRegister(String name, String address)
	{
		this.name = name;
		this.address = address;
	}

	public enum ContentType {
		Empty,
		Data,
		Offset,
		Address,
	}
	
	public VirtualRegister(int number)
	{
		this.number = number;
		this.name = "R" + number;
		this.address = offset + "($fp)";
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
		this.address = offset + "($fp)";
	}

	public int getNumber() {
		return number;
	}

	public String getName() {
		return name;
	}

	public ContentType getContentType() {
		return contentType;
	}
	
	public boolean isConstant()
	{
		return this.contentType.equals(ContentType.Data);
	}
	
	public boolean isOffset()
	{
		return this.contentType.equals(ContentType.Offset);
	}

	public boolean isAddress()
	{
		return this.contentType.equals(ContentType.Address);
	}
	public String getAdress()
	{
		return this.address;
	}

	public void setContentType(VirtualRegister.ContentType contentType) {
		this.contentType = contentType;
	}
}

