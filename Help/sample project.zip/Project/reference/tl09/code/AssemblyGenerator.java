package edu.utsa.tl09.code;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.TreeMap;

import edu.utsa.tl09.*;

public class AssemblyGenerator {
	SymbolTable table;
	TreeMap<String, Block> blocks;
	int registerNumber = 1;
	String tab = "              ";
	
	public AssemblyGenerator(SymbolTable table, TreeMap<String, Block> blocks, int registerNumber)
	{
		this.table = table;
		this.blocks = blocks;
		this.registerNumber = registerNumber;
	}
	

	private int freeMemoryStart = 0 ;
	private TreeMap<String, VirtualRegister> virtualRegisters = new TreeMap<String, VirtualRegister>();
	
	public void toAssembly(String fileName) throws IOException
	{
		PrintStream stream = new PrintStream(new FileOutputStream(fileName));

		this.assignMemory();
		stream.println(tab + ".text");
		stream.println(tab + ".globl main");
		stream.println("main:");
		stream.println(tab + "li $fp, 0x7ffffffc");
		
		for(String bl : this.blocks.keySet())
		{
			if( bl.equalsIgnoreCase(Constant.Bexit))
			{
				continue;
			}
			
			stream.println(bl + ":");
			
			this.list.clear();
			for(Instruction ins : this.blocks.get(bl).getInstructions())
			{
				this.list.clear();
				this.toAssembly(ins);
				for( String s : this.list )
				{
					stream.println(tab + s );
				}
			}
		}
		stream.println(Constant.Bexit + ":");		
		stream.println(tab + "li $a0, 10");
		stream.println(tab + "li $v0, 10");
		stream.println(tab + "syscall");
	}
	
	public VirtualRegister getRegister(String reg)
	{
		return this.virtualRegisters.get(reg);
	}
	
	private static TreeMap<String, String> binaryOperationCode = new TreeMap<String, String>();
	static {
		 binaryOperationCode.put("cmp", "seq"); 
		 binaryOperationCode.put("cmp_LE", "sle"); 
		 binaryOperationCode.put("cmp_GE" , "sge"); 
		 binaryOperationCode.put( "cmp_GT" , "sgt"); 
		 binaryOperationCode.put( "cmp_LT" , "slt"); 
		 binaryOperationCode.put( "cmp_NE" , "sne"); 
		 binaryOperationCode.put( "add" , "addu"); 
		 binaryOperationCode.put( "sub" , "subu"); 
		 binaryOperationCode.put( "mult" , "mul"); 
		 binaryOperationCode.put( "div" , "divu"); 
	}
	
	ArrayList<String> list = new ArrayList<String>();
	
	private void toAssembly(Instruction ins) {
		if( Debug.CODE )
		list.add("# " + ins.toString());
		
		if( "loadI" . equalsIgnoreCase(ins.code) )
		{
			VirtualRegister op3 = this.virtualRegisters.get(ins.op3);
			
			if( ins.isConstantOp1() )
			{
				op3.setContentType(VirtualRegister.ContentType.Data);
				list.add("li $t0, " + ins.op1);
			}
			else if ( ins.isOffset() )
			{
				op3.setContentType(VirtualRegister.ContentType.Offset);
				list.add("li $t0, " + this.getMemoryOffset(ins.op1));
			}
			else
			{
				Debug.println(Debug.ILOC, "ERROR: Missing " + ins.code);
			}
						
			list.add("sw $t0, " + op3.getAdress());			 
		} 
		else if( "readInt" . equalsIgnoreCase(ins.code) )
		{
			list.add("li $v0, 5");
			list.add("syscall");
			list.add("move $t0, $v0");
			list.add("lw $t1, " + this.getMemory(ins.op3));
			list.add("sw $t0, 0($t1)");			
		} 
		else if( "writeInt" . equalsIgnoreCase(ins.code) )
		{
			this.loadWord(ins.op3, "$t2");
			list.add("move $a0, $t2");
			list.add("li $v0, 1");
			list.add("syscall");			
		} 
		else if( ins.isBinaryOperator() ) 
		{
			String reg1 = this.loadWord(ins.op1, "$t0");
			String reg2 = this.loadWord(ins.op2, "$t1");

			list.add(binaryOperationCode.get(ins.code) + " $t2, " + reg1 + ", " + reg2 );

			if( reg1.equals("Rarp") && 
				( "add".equalsIgnoreCase(ins.code)||("sub".equalsIgnoreCase(ins.code)) ))
			{
				this.storeWord(ins.op3, "$t2", VirtualRegister.ContentType.Address);
			}
			else
			{
				this.storeWord(ins.op3, "$t2");
			}
		}
		else if( "jumpI" . equalsIgnoreCase(ins.code) )
		{
			list.add("j " +  ins.op3);
		} 
		else if( "loadAO" . equalsIgnoreCase(ins.code) )
		{
			// loadAO Rarp, Rx => Ry
			list.add("lw $t0, " + this.getMemory(ins.op2));
			list.add("addu $t1, $t0, $fp");
			list.add("lw $t2, 0($t1)");
			this.getRegister(ins.op3).setContentType(VirtualRegister.ContentType.Data);
			list.add("sw $t2, " + this.getMemory(ins.op3));
		} 
		else if( "storeAO" . equalsIgnoreCase(ins.code) )
		{
			// storeAO Rx, => Rarp, Ry
			String r1 = this.loadWord(ins.op1, "$t0");
			String r2 = this.loadWord(ins.op2, "$t1");
			String r3 = this.loadWord(ins.op3, "$t2");
			
			list.add("addu $t3, " + r2 + ", " + r3);
			list.add("sw " + r1 + ", 0($t3)");
		} 
		else if ( "cbr" . equalsIgnoreCase( ins.code ))
		{
			list.add("lw $t0, " + this.getMemory(ins.op1));
			list.add("beqz $t0, " + ins.op3);
			list.add("j " + ins.op2);
		} 
		else if ( "mod" . equalsIgnoreCase( ins.code ))
		{
			String reg1 = this.loadWord(ins.op1, "$t0");
			String reg2 = this.loadWord(ins.op2, "$t1");
			
			list.add( "div " + reg1 + ", " + reg2 );
			// list.add( "add $t4, $t4, $t4" );
			// list.add( "add $t4, $t4, $t4" );
			list.add( "mfhi $t2" );
					
			this.storeWord(ins.op3, "$t2");
		}
		else if ( "div" . equalsIgnoreCase( ins.code ))
		{
			String reg1 = this.loadWord(ins.op1, "$t0");
			String reg2 = this.loadWord(ins.op2, "$t1");
			
			list.add( "div " + reg1 + ", " + reg2 );
			// list.add( "add $t4, $t4, $t4" );
			// list.add( "add $t4, $t4, $t4" );
			list.add( "mflo $t2" );
					
			this.storeWord(ins.op3, "$t2");
		}
		else
		{
			Debug.println(Debug.ILOC, "ERROR: Missing " + ins.code);
		}
	}
	
	private void storeWord(String op, String r, VirtualRegister.ContentType type) 
	{
		if( op.startsWith("R") )
		{
			VirtualRegister vr = this.getRegister(op);
			vr.setContentType(type);
		}
		
		this.storeWord(op, r);
	}
	
	private void storeWord(String op, String r)
	{
		list.add("sw " + r + ", " + getMemory(op));
	}

	private String loadWord(String vr1, String reg)
	{
		if( vr1.equalsIgnoreCase("Rarp") )
		{
			return "$fp";
		}
		
		return loadWord(this.getRegister(vr1), reg);
	}
	
	private String loadWord(VirtualRegister vr1, String reg) 
	{		
		switch(vr1.getContentType())
		{
		case Address:
			list.add("lw " + reg + ", " + vr1.getAdress());
			list.add("lw " + reg + ", 0(" + reg + ")" );
			break;
		case Data:
		case Empty:
		case Offset:
			list.add("lw " + reg + ", " + vr1.getAdress() + "" );
			break;
		default:
			System.err.println("ERROR: " + vr1.getName());
		}
		
		return reg;
	}

	private void assignVirtualRegisters()
	{
		this.virtualRegisters.put(VirtualRegister.Rarp.getName(), VirtualRegister.Rarp);
		
		for( int i = 1 ; i < this.registerNumber ; i ++ )
		{
			VirtualRegister vr = new VirtualRegister(i);
			
			vr.setOffset(this.freeMemoryStart);
			this.freeMemoryStart -= 4;
			
			this.virtualRegisters.put(vr.getName(), vr);
		}
	}
	
	private void assignMemory()
	{
		this.freeMemoryStart = table.assignMemoryForVariables(this.freeMemoryStart);
		this.assignVirtualRegisters();
		
		if( Debug.CODE )
		{
			list.add("; \tStack\tVariables");

			for (String var : this.table.getVariables()) 
			{
				list.add("; \t" + this.getMemory("@" + var) + "\t" + var + "");	
			}

			list.add("; \tStack\tVRegisters");

			for( int i = 1 ; i < this.registerNumber ; i ++ ) 
			{
				String reg = "R" + i ;
				list.add("; \t" + this.getMemory(reg) + "\t" + reg + "");	
			}
		}
	}
	
	public String getMemory(String op)
	{
		int off = this.getMemoryOffset(op);
		
		if( off == 0 )
			return "$fp";
		
		return off + "($fp)";
	}
	
	private int getMemoryOffset(String op)
	{
		if( op.startsWith("R") )
		{
			return this.getRegisterMemory(op);
		}
		
		if( op.startsWith("@") )
		{
			op = op.replaceFirst("@", "");
			
			return this.table.getMemoryAddress(op);
		}
		
		return this.table.getMemoryAddress(op);
	}
	
	private int getRegisterMemory(String reg)
	{
		return this.virtualRegisters.get(reg).getOffset();
	}
}

