package edu.utsa.tl09.code;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;


import edu.utsa.tl09.Debug;
import edu.utsa.tl09.SymbolTable;
import edu.utsa.tl09.nodes.*;

public class CodeGenerator {
	Node root;
	SymbolTable table;
	int blockNumber = 0;
	int registerNumber = 1;
	
	ArrayList<Instruction> instructions = new ArrayList<Instruction>();
	TreeMap<String, Block> blocks = new TreeMap<String, Block>();
	String currentBlock = null;
	
	public String getNextRegister()
	{
		return "R" + this.registerNumber ++;
	}
	
	public String getNextBlockLabel()
	{
		return getNextBlockLabel("");
	}
	
	public String getNextBlockLabel(String append) {
		return "B" + this.blockNumber ++ + (Debug.ILOC?append:"");
	}	
	
	
	public CodeGenerator(Node root, SymbolTable table)
	{
		this.root = root;
		this.table = table;
	}
	
	public void generate()
	{
		this.root.toILOC(this);
	}
	
	public void instruction(String opCode, String op1, String op2, String op3)
	{
		Instruction instruction = new Instruction(opCode, op1, op2, op3);
		instruction.number = getInstructionNumber();
		/*
		if( this.currentBlock == null )
		{
			this.currentBlock = this.getNextBlockNumber();
		}
		*/
		
		if( !this.blocks.containsKey(this.currentBlock) )
		{
			// this.blocks.put(this.currentBlock, new Block(this.currentBlock));
		}
		
		this.blocks.get(this.currentBlock).add(instruction);
		this.instructions.add(instruction);
		
		Debug.println(Debug.ILOC, instruction);

	}
	
	public int getInstructionNumber()
	{
		return this.instructions.size();
	}
	
	public void instruction(String opCode, String op1, String op3)
	{
		this.instruction(opCode, op1, null, op3);
	}

	public void instruction(String opCode, String op3)
	{
		this.instruction(opCode, null, null, op3);
	}

	public String startBlock(String blockLabel)
	{
		return this.startBlock(blockLabel, null);
	}
	
	public String startBlock(String blockLabel, String append)
	{
		if( blockLabel == null && append != null )
		{
			blockLabel = getNextBlockLabel(append);
		}
		
		if( this.currentBlock == blockLabel )
		{
			return this.currentBlock;
		}
		
		if( this.currentBlock != null )
		{
			this.endCurrentBlock();
		}
		
		this.currentBlock = blockLabel;
		
		if( this.currentBlock != null )
		{
			if( this.blocks.containsKey(this.currentBlock) 
				&& !this.blocks.get(this.currentBlock).getInstructions().isEmpty())
			{
				Debug.println(Debug.ILOC, "ERROR Block: " + this.currentBlock + " Starting again. Will erase existing code in this block.");
			}
			this.blocks.put(this.currentBlock, new Block(this.currentBlock));
		}

		if( this.currentBlock != null )
		{
			Debug.println(Debug.ILOC, this.currentBlock + ":");		
		}
		
		return this.currentBlock;

	}
	
	public String startBlockIfNeeded() {
		return this.startBlockIfNeeded("");
	}
	
	public String startBlockIfNeeded(String blockLabel) {
		if( this.currentBlock == null )
		{
			this.startBlock(blockLabel, null);
			
			return this.currentBlock;
		}
		
		return null;
	}
		
	public void endCurrentBlock()
	{
		if( this.currentBlock != null )
		{
			Debug.println(Debug.ILOC, this.currentBlock + ": END");
		}
		this.currentBlock = null;
	}
	
	public String getCurrentBlockLabel()
	{
		return this.currentBlock;
	}
	
	public Block getCurrentBlock()
	{
		return this.blocks.get(this.currentBlock);
	}
	
	public Block getBlock(String blockLabel)
	{
		return this.blocks.get(blockLabel);
	}
	
	public void dump() {
		for (Block block : this.blocks.values()) {
			block.dump();
		}
	}

	public void toCfgGraph(String fileName) throws IOException {
		if( Debug.ILOC )
		{
			/*
			 * Counts the incoming nodes to each block.
			 * Should be atleast 1 for all but B0
			 */
			HashMap<String, Integer> inCount = new HashMap<String, Integer>();
			for(String block : this.blocks.keySet() )
				inCount.put(block, 0);
			
			for(Block block : this.blocks.values() )
				for(String out : block.getOutBlocks() )
					inCount.put(out, inCount.get(out)+1);
			
			for(String block : inCount.keySet() )
				if( !block.equals("B0") && inCount.get(block) < 1 )
					Debug.println(Debug.ILOC, "ERROR Block: " + block + " has no incoming.");
		}
		
		PrintStream stream = new PrintStream(new FileOutputStream(fileName));
		// stream = System.out;
		stream.println("digraph tl07 {");
		stream.println("\tordering=out;");
		stream.println("\tnode [shape = box];");
		stream.println("\tnode [style = filled];");

		for(Block block : this.blocks.values())
		{
			stream.println(block.toGraphNode());
		}
		
		for(Block block : this.blocks.values())
		{
			stream.println(block.toGraphEdge());
		}					
		
		stream.println("}");
	}

	public TreeMap<String, Block> getBlocks() {
		return this.blocks;
	}

	public int getRegisterNumber() {
		return this.registerNumber;
	}
}

