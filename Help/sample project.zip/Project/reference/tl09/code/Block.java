package edu.utsa.tl09.code;

import java.util.ArrayList;


public class Block {
	String blockLabel;	
	ArrayList<Instruction> instructions = new ArrayList<Instruction>();
	ArrayList<String> outBlocks = new ArrayList<String>();
	
	public Block(String blockLabel)
	{
		this.blockLabel = blockLabel;
	}
	
	public void add(Instruction instruction) {
		this.instructions.add(instruction);		
		this.outBlocks.addAll(instruction.getOutBlocks());
	}

	public void dump() {
		StringBuilder sb = new StringBuilder();
		
		sb.append(blockLabel);
		sb.append(':');
		sb.append("\n");
		
		for (Instruction x : this.instructions) {
			sb.append(x.toString());
			sb.append("\n");
		}
		
		System.out.println(sb.toString());	
	}

	public String toGraphNode() {
		StringBuilder sb = new StringBuilder();
		
		sb.append('\t');
		sb.append(blockLabel);
		sb.append(' ');
		sb.append('[');
		sb.append("label=\"");
		sb.append(blockLabel);
		sb.append(": ");
		sb.append("\\l");
		for (Instruction x : this.instructions) {
			sb.append(x.toString());
			sb.append("\\l");
		}
		sb.append("\"");
		sb.append("];");
		
		return sb.toString();	
	}

	public String getBlockLabel() {
		return blockLabel;
	}

	public ArrayList<Instruction> getInstructions() {
		return instructions;
	}

	public ArrayList<String> getOutBlocks() {
		return outBlocks;
	}

	public String toGraphEdge() {
		StringBuilder sb = new StringBuilder();
		
		for( String des : this.outBlocks )
		{
			sb.append('\t');
			sb.append(blockLabel);
			sb.append(" -> ");
			sb.append(des);
			sb.append(";");
			sb.append("\n");
		}
		
		return sb.toString();
	}
}

