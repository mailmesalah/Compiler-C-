package edu.utsa.tl09;

import edu.utsa.tl09.nodes.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

public class Scanner {
	private LinkedList<Token> tokens = new LinkedList<Token>(); 
	private String fileName;
	private int lineNumber;
	
	public Scanner(String fileName)
	{
		this.fileName = fileName;
	}
	
	public Token look()
	{
		if( tokens.isEmpty() )
		{
			return Token.EOF;
		}
		
		return tokens.getFirst();
	}

	public NodeType lookType()
	{
		return this.look().getType();
	}

	public boolean isLookType(NodeType type)
	{
		return this.look().getType() == type;
	}
	
	public Token get()
	{
		if( tokens.isEmpty() )
		{
			return Token.EOF;
		}

		return tokens.removeFirst();
	}
	
	public void scan() throws IOException
	{
		
		this.lineNumber = 0;
		
        BufferedReader reader = new BufferedReader(
                new FileReader(this.fileName));
        
        String line;
        
        while( (line = reader.readLine()) != null )
        {
        	this.lineNumber++;
        	this.tokenize(line);
        }

        reader.close();		
	}
	
	private void addLast(Token token)
	{
		token.lineNumber = this.lineNumber;
		this.tokens.addLast(token);
		// System.out.println(token);
		token.fileName = this.fileName;
	}
	
	private void tokenize(String line)
	{
		String[] words = line.split("\\s+");  
		
		for (String word : words) {
			if( word == null )
				continue;
			
			word = word.trim();
			
			if( word.length() == 0 )
				continue;
			
			/*
			Built-in Procedures:
			
			    * WRITEINT = "WRITEINT"
			    * READINT = "READINT" 			
			 */
			if( word.equals("WRITEINT") )
			{
				addLast(new Token(NodeType.WRITEINT, word));
			} 
			else if ( word.equals("READINT") )
			{
				addLast(new Token(NodeType.READINT, word));
			}
			/*
			Keywords:
			
		    * IF = "IF"
		    * THEN = "THEN"
		    * ELSE = "ELSE"
		    * BEGIN = "BEGIN"
		    * END = "END"
		    * WHILE = "WHILE"
		    * DO = "DO"
		    * PROGRAM = "PROGRAM"
		    * VAR = "VAR"
		    * AS = "AS"
		    * INT = "INT"
		    * BOOL = "BOOL" 
			*/
			else if ( word.equals("IF") )
			{
				addLast(new Token(NodeType.IF, word));
			}
			else if ( word.equals("THEN") )
			{
				addLast(new Token(NodeType.THEN, word));
			}
			else if ( word.equals("ELSE") )
			{
				addLast(new Token(NodeType.ELSE, word));
			}
			else if ( word.equals("BEGIN") )
			{
				addLast(new Token(NodeType.BEGIN, word));
			}
			else if ( word.equals("END") )
			{
				addLast(new Token(NodeType.END, word));
			}
			else if ( word.equals("WHILE") )
			{
				addLast(new Token(NodeType.WHILE, word));
			}
			else if ( word.equals("DO") )
			{
				addLast(new Token(NodeType.DO, word));
			}
			else if ( word.equals("PROGRAM") )
			{
				addLast(new Token(NodeType.PROGRAM, word));
			}
			else if ( word.equals("VAR") )
			{
				addLast(new Token(NodeType.VAR, word));
			}
			else if ( word.equals("AS") )
			{
				addLast(new Token(NodeType.AS, word));
			}
			else if ( word.equals("INT") )
			{
				addLast(new Token(NodeType.INT, word));
			}
			else if ( word.equals("BOOL") )
			{
				addLast(new Token(NodeType.BOOL, word));
			}
			/*
		    * LP = "("
		    * RP = ")"
		    * ASGN = ":="
		    * SC = ";"
		    * OP2 = "*" | "/" | "%"
		    * OP3 = "+" | "-"
		    * OP4 = "==" | "!=" | "<" | ">" | "<=" | ">=" 
			*/
			else if ( word.equals("(") )
			{
				addLast(new Token(NodeType.LP, word));
			}
			else if ( word.equals(")") )
			{
				addLast(new Token(NodeType.RP, word));
			}
			else if ( word.equals(":=") )
			{
				addLast(new Token(NodeType.ASGN, word));
			}
			else if ( word.equals(";") )
			{
				addLast(new Token(NodeType.SC, word));
			}
			else if ( word.equals("*") || word.equals("/") || word.equals("%") )
			{
				addLast(new Token(NodeType.OP2, word));
			}
			else if ( word.equals("+") || word.equals("-") )
			{
				addLast(new Token(NodeType.OP3, word));
			}
			else if ( word.equals("==") || word.equals("!=") || word.equals("<") 
				|| word.equals(">") || word.equals("<=") || word.equals(">=") )
			{
				addLast(new Token(NodeType.OP4, word));
			}
			
			/*
			Numbers, Literals, and Identifiers:
			
		    * num = (-|e)[1-9][0-9]*|0
		    * boollit = FALSE|TRUE
		    * ident = [a-z][a-z0-9]* 
		    */
			else if ( word.matches("(FALSE)|(TRUE)") )
			{
				addLast(new Token(NodeType.BOOLLIT, word, word.equals("TRUE")));
			}
			else if (word.matches("((-|e)?[1-9][0-9]*)|0"))
			{
				try {
					addLast(new Token(NodeType.NUMBER, word, Integer.parseInt(word)));	
				} 
				catch(NumberFormatException nfex)
				{
					System.err.println("SCANNER ERROR " + this.fileName + ":" + this.lineNumber + " Bad number: " + nfex.getMessage());
					
					Token t = new Token(NodeType.NUMBER, word, Integer.MAX_VALUE);
					
					t.nodeDataType = NodeType.Error;					
					addLast(t);
				}
			}
			else if (word.matches("[a-z][a-z0-9]*"))
			{
				addLast(new Token(NodeType.IDENT, word));
			}
			else 
			{
				System.err.println("SCANNER ERROR " + this.fileName + ":" + this.lineNumber + " Unknown token : '" + word + "'");
			}
		}
	}
}

