package edu.utsa.tl09;

import edu.utsa.tl09.nodes.Node;
import edu.utsa.tl09.nodes.NodeType;

public class Token extends Node {
	private String value;
	private int intValue;
	private boolean boolValue;
	public String fileName;
	public int lineNumber;
	
	public static final Token EOF = new Token(NodeType.EOF, "EOF");
		
	public Token(NodeType type, String value)
	{
		super(type);
		this.value = value;
	}	
	
	public Token(NodeType type, String value, int intValue)
	{
		super(type);
		this.value = value;
		this.intValue = intValue;
		this.nodeDataType = NodeType.INT;
	}	
	
	public Token(NodeType type, String value, boolean boolValue)
	{
		super(type);
		this.value = value;
		this.boolValue = boolValue;
		this.nodeDataType = NodeType.BOOL;
	}	
	
	
	public int getIntValue()
	{
		return this.intValue;
	}
	
	public boolean getBoolValue()
	{
		return this.boolValue;
	}

	public String getValue()
	{
		return this.value;
	}

	public NodeType getType()
	{
		return super.nodeType;
	}
	
	public String toString()
	{
		String pre = "";
		
		switch(super.nodeType)
		{
		case IDENT:
			pre = "ident: ";
			break;
			
		case NUMBER:
			pre = "number: ";
			break;
			
		case BOOLLIT:
			pre = "boollit: ";
			break;
			
		default:
			break;
		}
		
		return /*this.lineNumber + ":\t" + */ pre + this.value;
	}
	
	@Override
	protected boolean isAstVisible()
	{
		switch (this.nodeType) 
		{
		case NUMBER:			
		case IDENT: 
		case BOOLLIT:
			return true;
		
		/*
		case ASGN:
		case OP2:
		case OP3:
		case OP4:
			return true;
		*/
			
		case INT:
		case BOOL:
			return true;

		default:
			return false;
		}
	}
	
	@Override 
	protected String getAstLabel()
	{
		return this.value;
	}
}

