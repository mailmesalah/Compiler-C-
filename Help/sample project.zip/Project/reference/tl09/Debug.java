package edu.utsa.tl09;

public class Debug {
	public static final boolean ILOC = false;
	public static final boolean CODE = false;
	
	public static void println(boolean area, Object s)
	{
		if( area )
			System.out.println(s);
	}
	
}

