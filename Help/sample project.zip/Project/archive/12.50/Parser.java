import java.util.ArrayList;

public class Parser {
	public static ArrayList tokens = new ArrayList();
	public static String fileName;
	public static int count=0;
	public static int flag=1;
	public static String lookAhead= " ";
	
	//Tree Declarations
	TreeNode<String> declarationNode;
	TreeNode<String> programNode;
	TreeNode<String> beginNode;
	TreeNode<String> statementSequenceNode;
	TreeNode<String> endNode;
	TreeNode<String> varNode;
	TreeNode<String> idenNode;
	TreeNode<String> asNode;
	TreeNode<String> scNode;
	TreeNode<String> typeNode;
	TreeNode<String> intNode;
	TreeNode<String> boolNode;
	TreeNode<String> statementNode;
	TreeNode<String> assignmentNode;
	TreeNode<String> ifStatementNode;
	TreeNode<String> whileStatementNode;
	TreeNode<String> writeintNode;
	TreeNode<String> asgnNode;
	TreeNode<String> assignmentModifiedNode;
	TreeNode<String> expressionNode;
	TreeNode<String> readInt;
	TreeNode<String> ifNode;
	TreeNode<String> thenNode;
	TreeNode<String> elseClauseNode;
	TreeNode<String> elseNode;
	TreeNode<String> whileNode;
	TreeNode<String> doNode;
	TreeNode<String> compareNode;
	TreeNode<String> compNode;
	TreeNode<String> simpleExpressionNode;
	TreeNode<String> writeNode;
	TreeNode<String> termNode;
	TreeNode<String> addNode;
	TreeNode<String> additiveNode;
	TreeNode<String> rpNode;
	TreeNode<String> lpNode;
	TreeNode<String> boollitNode;
	TreeNode<String> numNode;
	TreeNode<String> multiNode;
	TreeNode<String> factorNode;
	TreeNode<String> multiplicativeNode;
	TreeNode<String> emptyNode;
			
	//Tree Declarations Ends
	
	public Parser(ArrayList tokens,String fileName){
		this.tokens=tokens;
		this.fileName=fileName;
		lookAhead = (String)tokens.get(count);
	}
	
	public void Parsing(){
		this.program();
		if(lookAhead.equals("END") && flag==1){
			System.out.println("Parsing Success");
		}	
		DotGeneration dot=new DotGeneration(fileName);
		dot.Generator(programNode);
	}
	
	public void match(String token){
		if(token.equals(lookAhead)&&count<tokens.size()-1){
			lookAhead=(String)tokens.get(++count);
		}
		else if(!token.equals(lookAhead)){
			System.out.println("Parsing Error Expected: " + token + " Found: " + lookAhead);
			flag=0;
		}
	}
	
	// <program>::=PROGRAM <declarations> BEGIN <statementSequence> END
	public void program(){
		if(lookAhead.equals("PROGRAM")){
			programNode = new TreeNode<String>(lookAhead);
			this.match("PROGRAM");			
			declarationNode = programNode.addChild("decl list");
			this.declarations();
			this.match("BEGIN");
			statementSequenceNode = programNode.addChild("stmt list");
			this.statementSequence();
			this.match("END");
		}
	}
	
	//<declarations>::=VAR ident AS <type> SC <declarations>|E
		static String iden="";
		public void declarations(){
			if(lookAhead.equals("VAR")){
				this.match("VAR");
				if(lookAhead.contains("iden(")){
					iden=lookAhead;
					this.match(lookAhead);
				}
				this.match("AS");
				this.type();
				idenNode = declarationNode.addChild("decl:'" + iden.substring(5,iden.length()-1) + "':" + type);
				this.match("SC(;)");
				this.declarations();
			}
			else{
				return;
			}
		}
		static String type;
		//<type>::=INT||BOOL
		public void type(){
			if(lookAhead.equals("INT")){
				this.match("INT");
				type="int";
			}
			else if(lookAhead.equals("BOOL")){
				this.match("BOOL");
				type="bool";
			}
		}
	
	//<statementSequence>::=<statement> SC <statementSequence> | E
	public void statementSequence(){
		if(lookAhead.contains("iden(")||lookAhead.equals("IF")||lookAhead.equals("WHILE")||lookAhead.equals("WRITEINT")){
			//statementNode = statementSequenceNode.addChild("Statement");
			this.statement();
			this.match("SC(;)");
			//statementNode = statementNode.addChild("StatementSequence");
			this.statementSequence();
		}
		else{
			return;
		}
	}
	
	//<statement>::=<assignment>||<ifStatement>||<whileStatement>||<writeInt>
	public void statement(){
		if(lookAhead.contains("iden(")){
			assignmentNode = statementSequenceNode.addChild(":=");
			this.assignment();
		}
		else if(lookAhead.equals("IF")){
			ifStatementNode = statementSequenceNode.addChild("if");
			this.ifStatement();
		}
		else if(lookAhead.equals("WHILE")){
			whileStatementNode = statementSequenceNode.addChild("while");
			this.whileStatement();
		}
		else if(lookAhead.equals("WRITEINT")){
			writeintNode = statementSequenceNode.addChild("writeint");
			this.writeInt();
		}
	}
	
	//<assignment>::=ident ASGN <assignmentModified>
	public void assignment(){
		if(lookAhead.contains("iden(")){
			idenNode = assignmentNode.addChild(lookAhead.substring(5,lookAhead.length()-1));
			this.match(lookAhead);
			//asgnNode = assignmentNode.addChild(":=");
			this.match("ASGN(:=)");
			//assignmentModifiedNode=assignmentNode.addChild("assignmentModified");
			this.assignmentModified();
		}
	}
	
	//<assignmentModified>::=<expression>|READINT
	public void assignmentModified(){
		if(lookAhead.contains("iden(")||lookAhead.contains("num(")||lookAhead.contains("boollit(")||lookAhead.equals("LP(()")){
			expressionNode = assignmentNode.addChild("expression");
			this.expression();
		}
		else if(lookAhead.equals("READINT")){
			readInt = assignmentNode.addChild("readint");
			this.match("READINT");
		}
	}
	
	//<ifStatement>::=IF<expression> THEN <statementSequence> <elseClause> END
	public void ifStatement(){
		if(lookAhead.equals("IF")){
			this.match("IF");
			expressionNode = ifStatementNode.addChild("expression");
			this.expression();
			this.match("THEN");
			statementSequenceNode = ifStatementNode.addChild("StatementSequence");
			this.statementSequence();
			elseClauseNode = ifStatementNode.addChild("elseClause");
			this.elseClause();
			this.match("END");
		}
	}
	
	//<elseClause>::=ELSE<statementSequence>|E
	public void elseClause(){
		if(lookAhead.equals("ELSE")){
			elseNode = elseClauseNode.addChild("else");
			this.match("ELSE");
			statementSequenceNode = elseClauseNode.addChild("StatementSequnce");
			this.statementSequence();
		}
		else{
			return;
		}
	}
	
	//<whileStatement>::=WHILE<expression> DO <statementSequence> END
	public void whileStatement(){
		if(lookAhead.equals("WHILE")){
			this.match("WHILE");
			expressionNode = whileStatementNode.addChild("expression");
			this.expression();
			this.match("DO");
			statementSequenceNode = whileStatementNode.addChild("StatementSequence");
			this.statementSequence();
			this.match("END");
		}
	}
	
	//<writeint>::=WRITEINT<expression>
	public void writeInt(){
		if(lookAhead.equals("WRITEINT")){
			this.match("WRITEINT");
			expressionNode = writeintNode.addChild("Expression");
			this.expression();
		}
	}
	
	//<expression>::=<simpleExpression><comp>
	public void expression(){
		if(lookAhead.contains("iden(")||lookAhead.contains("num(")||lookAhead.contains("boollit(")||lookAhead.equals("LP(()")){
			simpleExpressionNode = expressionNode.addChild("SimpleExpression");
			this.simpleExpression();
			//compNode = expressionNode.addChild("Compare");
			this.comp();
		}
	}
	
	//<comp>::=COMPARE<expression>|E
	public void comp(){
		if(lookAhead.contains("COMPARE")){
			compareNode = expressionNode.addChild(lookAhead.substring(8,lookAhead.length()-1));
			this.match(lookAhead);
			expressionNode = expressionNode.addChild("Expression");
			this.expression();
		}
		else{
			return;
		}
	}
	
	//<simpleExpression>::=<term><add>
	public void simpleExpression(){
		if(lookAhead.contains("iden(")||lookAhead.contains("num(")||lookAhead.contains("boollit(")||lookAhead.equals("LP(()")){
			//termNode = simpleExpressionNode.addChild("Term");
			this.term();
			//addNode = simpleExpressionNode.addChild("Add");
			this.add();
		}
	}
	
	//<add>::==ADDITIVE<simpleExpression>|E
	public void add(){
		if(lookAhead.contains("ADDITIVE(")){
			additiveNode = simpleExpressionNode.addChild(lookAhead.substring(9,lookAhead.length()-1));
			this.match(lookAhead);
			simpleExpressionNode = simpleExpressionNode.addChild("SimpleExpression");
			this.simpleExpression();
		}
		else{
			return;
		}
	}
	
	//<term>::=<factor><multi>
	public void term(){
		if(lookAhead.contains("iden(")||lookAhead.contains("num(")||lookAhead.contains("boollit(")||lookAhead.equals("LP(()")){
			//factorNode = termNode.addChild("Factor");
			this.factor();
			//multiNode = termNode.addChild("Multi");
			this.multi();
		}
	}
	
	//<multi>::=MULTIPLICATIVE<term>|E
	public void multi(){
		if(lookAhead.contains("MULTIPLICATIVE(")){
			multiplicativeNode = simpleExpressionNode.addChild(lookAhead.substring(15,lookAhead.length()-1));
			this.match(lookAhead);
			//termNode = simpleExpressionNode.addChild("Term");
			this.term();
		}
		else{
			return;
		}
	}
	
	//<factor>::=ident|num|boollit|LP<expression>RP
	public void factor(){
		if(lookAhead.contains("iden(")){
			idenNode = simpleExpressionNode.addChild(lookAhead.substring(5,lookAhead.length()-1));
			this.match(lookAhead);
		}
		else if(lookAhead.contains("num(")){
			numNode = simpleExpressionNode.addChild(lookAhead.substring(4,lookAhead.length()-1));
			this.match(lookAhead);
		}
		else if(lookAhead.contains("boollit(")){
			boollitNode = simpleExpressionNode.addChild(lookAhead.substring(8,lookAhead.length()-1));
			this.match(lookAhead);
		}
		else if(lookAhead.equals("LP(()")){
			lpNode = simpleExpressionNode.addChild(lookAhead.substring(3,lookAhead.length()-1));
			this.match("LP(()");
			expressionNode = simpleExpressionNode.addChild("expression");
			this.expression();
			rpNode = simpleExpressionNode.addChild(lookAhead.substring(3,lookAhead.length()-1));
			this.match("RP())");
		}
	}
}
