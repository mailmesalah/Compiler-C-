package edu.utsa.ppg583.main;

import java.util.ArrayList;

import edu.utsa.ppg583.nodes.NodeType;

public class SymbolTableEntry {
	public String symbolName;
	public NodeType symbolType = NodeType.empty;
	public Token nameToken;
	public Token typeToken;
	public ArrayList<Token> refereneces = new ArrayList<Token>();
	int memoryAddress;
}

