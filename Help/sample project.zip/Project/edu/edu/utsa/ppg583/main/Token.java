package edu.utsa.ppg583.main;

import edu.utsa.ppg583.nodes.Node;
import edu.utsa.ppg583.nodes.NodeType;

public class Token extends Node {
	private String value;
	private int intValue;
	private boolean boolValue;
	public String fileName;
	public int lineNumber;

	public static final Token EOF = new Token(NodeType.EOF, "EOF");

	public Token(NodeType type) {
		super(type);
	}

	public Token(NodeType type, String value) {
		super(type);
		this.value = value;
	}

	public Token(NodeType type, String value, int intValue) {
		super(type);
		this.value = value;
		this.intValue = intValue;
		this.nodeDataType = NodeType.INT;
	}

	public Token(NodeType type, String value, boolean boolValue) {
		super(type);
		this.value = value;
		this.boolValue = boolValue;
		this.nodeDataType = NodeType.BOOL;
	}

	public int getIntValue() {
		return this.intValue;
	}

	public boolean getBoolValue() {
		return this.boolValue;
	}

	public String getValue() {
		return this.value;
	}

	public NodeType getType() {
		return super.nodeType;
	}

	public String toString() {
		String post = "";

		switch (super.nodeType) {
		case ident:
		case num:
		case MULTIPLICATIVE: 
		case ADDITIVE: 
			post = ":int";
			break;
		case COMPARE:
			post =":bool";
			
		default:
			break;
		}

		return this.value + post;
	}

	@Override
	protected boolean isAstVisible() {
		switch (this.nodeType) {
		case num:
		case ident:
		case boollit:
			return true;

		case INT:
		case BOOL:
			return true;

		default:
			return false;
		}
	}

	@Override
	protected String getAstLabel() {
		String post = "";

		switch (super.nodeType) {
		case ident:
		case num:
		case MULTIPLICATIVE: 
		case ADDITIVE: 
			post = ":int";
			break;
		case COMPARE:
			post =":bool";
			
		default:
			break;
		}

		return this.value + post;
	}
}
