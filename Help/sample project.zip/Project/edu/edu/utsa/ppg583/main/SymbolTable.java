package edu.utsa.ppg583.main;

import java.util.ArrayList;
import java.util.TreeMap;

import edu.utsa.ppg583.nodes.*;

public class SymbolTable {
	private Node tree;
	private ArrayList<String> variables = new ArrayList<String>();
	private TreeMap<String, SymbolTableEntry> table = new TreeMap<String, SymbolTableEntry>();

	public SymbolTable(Node tree) {
		this.tree = tree;
	}

	public void create() {
		tree.annotate(this);
	}

	public ArrayList<String> getVariables() {
		return variables;
	}

	public int getMemoryAddress(String var) {
		return this.table.get(var).memoryAddress;
	}

	public int assignMemoryForVariables(int memoryStart) {
		for (int i = 0; i < variables.size(); i++) {
			table.get(variables.get(i)).memoryAddress = memoryStart;
			memoryStart = memoryStart - 4;
		}

		return memoryStart;
	}

	public boolean declare(Token variableName, Token variableType) {
		boolean success = true;
		String name = variableName.getValue();

		if (this.table.containsKey(name)) {
			success = false;
			Token place = variableName;
			String errorString = "TYPE ERROR " + place.fileName + ":" + place.lineNumber + " " + place.getValue()
					+ " Duplicate declaration.";
			System.err.println(errorString);
		}

		SymbolTableEntry entry = new SymbolTableEntry();

		entry.symbolName = name;
		entry.symbolType = variableType.getType();

		entry.nameToken = variableName;
		entry.typeToken = variableType;

		this.table.put(name, entry);
		this.variables.add(name);
		this.addReference(variableName);

		return success;
	}

	public void addReference(Token variableToken) {

		if (!this.table.containsKey(variableToken.getValue())) {
			Token place = variableToken;
			String errorString = "TYPE ERROR " + place.fileName + ":" + place.lineNumber + " " + place.getValue()
					+ " Undeclared.";
			System.err.println(errorString);

			variableToken.nodeDataType = NodeType.Error;

			return;
		}

		SymbolTableEntry entry = this.table.get(variableToken.getValue());
		entry.refereneces.add(variableToken);
		variableToken.nodeDataType = entry.symbolType;
	}
}
