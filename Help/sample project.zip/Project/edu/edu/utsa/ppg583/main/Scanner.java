package edu.utsa.ppg583.main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

import edu.utsa.ppg583.nodes.*;

public class Scanner {
	private LinkedList<Token> tokens = new LinkedList<Token>();
	private String fileName;
	private int lineNumber;

	public Scanner(String fileName) {
		this.fileName = fileName;
	}

	public String extension(String fileName) {
		int dot = fileName.lastIndexOf(".");
		return fileName.substring(dot + 1);
	}

	public Token look() {
		if (tokens.isEmpty()) {
			return Token.EOF;
		}

		return tokens.getFirst();
	}

	public NodeType lookType() {
		return this.look().getType();
	}

	public boolean isLookType(NodeType type) {
		return this.look().getType() == type;
	}

	public Token get() {
		if (tokens.isEmpty()) {
			return Token.EOF;
		}

		return tokens.removeFirst();
	}

	public LinkedList scan() throws IOException {

		this.lineNumber = 0;

		BufferedReader reader = new BufferedReader(new FileReader(this.fileName));

		String line;

		while ((line = reader.readLine()) != null) {
			this.lineNumber++;
			this.tokenize(line);
		}

		reader.close();
		return tokens;
	}

	private void addLast(Token token) {
		token.lineNumber = this.lineNumber;
		this.tokens.addLast(token);
		token.fileName = this.fileName;
	}

	private void tokenize(String line) {
		String[] words = line.split("\\s+");

		for (String word : words) {
			if (word == null)
				continue;

			word = word.trim();

			if (word.length() == 0)
				continue;

			/**
			 * Comments --------------------------------- The first occurrence
			 * of the character "%" on a line denotes the start of a comment
			 * that extends to the end of that line
			 */
			if (word.startsWith(("%")))
				break;

			/**
			 * Symbols and Operators:
			 */

			/**
			 * Symbols:
			 * -----------------------------------------------------------------
			 * LP = "(" RP = ")" ASGN = ":=" SC = ";"
			 */
			if (word.equals("("))
				addLast(new Token(NodeType.LP, word ));
			else if (word.equals(")"))
				addLast(new Token(NodeType.RP, word ));
			else if (word.equals(":="))
				addLast(new Token(NodeType.ASGN, word ));
			else if (word.equals(";"))
				addLast(new Token(NodeType.SC, word ));
			/**
			 * Operators
			 * -----------------------------------------------------------------
			 * MULTIPLICATIVE = "*" | "div" | "mod" ADDITIVE = "+" | "-" COMPARE
			 * = "=" | "!=" | "<" | ">" | "<=" | ">="
			 */
			else if (word.equals("*") || word.equals("div") || word.equals("mod"))
				addLast(new Token(NodeType.MULTIPLICATIVE, word ));
			else if (word.equals("+") || word.equals("-"))
				addLast(new Token(NodeType.ADDITIVE, word ));
			else if (word.equals("=") || word.equals("!=") || word.equals("<") || word.equals(">") || word.equals("<=")
					|| word.equals(">="))
				addLast(new Token(NodeType.COMPARE, word ));
			/**
			 * Keywords:
			 */
			/**
			 * IF = "if" THEN = "then" ELSE = "else" BEGIN = "begin" END = "end"
			 * WHILE = "while" DO = "do" PROGRAM = "program" VAR = "var" AS="as"
			 * INT = "int" BOOL = "bool"
			 */
			else if (word.equals("if"))
				addLast(new Token(NodeType.IF, word));
			else if (word.equals("then"))
				addLast(new Token(NodeType.THEN, word));
			else if (word.equals("else"))
				addLast(new Token(NodeType.ELSE, word));
			else if (word.equals("begin"))
				addLast(new Token(NodeType.BEGIN, word));
			else if (word.equals("end"))
				addLast(new Token(NodeType.END, word));
			else if (word.equals("while"))
				addLast(new Token(NodeType.WHILE, word));
			else if (word.equals("do"))
				addLast(new Token(NodeType.DO, word));
			else if (word.equals("program"))
				addLast(new Token(NodeType.program, word));
			else if (word.equals("var"))
				addLast(new Token(NodeType.VAR, word));
			else if (word.equals("as"))
				addLast(new Token(NodeType.AS, word));
			else if (word.equals("int"))
				addLast(new Token(NodeType.INT, word));
			else if (word.equals("bool"))
				addLast(new Token(NodeType.BOOL, word));

			/**
			 * Built-in Procedures:
			 */
			/**
			 * WRITEINT = "writeint" READINT = "readint"
			 */
			else if (word.equals("writeint"))
				addLast(new Token(NodeType.WRITEINT, word ));
			else if (word.equals("readint"))
				addLast(new Token(NodeType.READINT, word ));

			/**
			 * Numbers, Literals, and Identifiers:
			 * 
			 */
			/**
			 * num = [1-9][0-9]*|0
			 */
			else if (word.matches("[1-9][0-9]*|0"))
				addLast(new Token(NodeType.num, word ));
			/**
			 * boollit = false|true
			 */
			else if (word.equals("false") || word.equals("true"))
				addLast(new Token(NodeType.boollit, word ));

			/**
			 * ident = [A-Z][A-Z0-9]*
			 */
			else if (word.matches("[A-Z][A-Z0-9]*"))
				addLast(new Token(NodeType.ident, word ));

			else
				System.err.println(
						"SCANNER ERROR " + this.fileName + ":" + this.lineNumber + " Unknown token : '" + word + "'");
		}
	}
}
