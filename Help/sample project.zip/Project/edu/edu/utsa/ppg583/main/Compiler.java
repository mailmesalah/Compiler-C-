package edu.utsa.ppg583.main;

import java.io.IOException;
import java.util.LinkedList;

import edu.utsa.ppg583.main.Parser;
import edu.utsa.ppg583.nodes.Node;

public class Compiler {

	public static final String PPG583 = "tl"; // input file format <basename>.tl
	public static final String TKDOT = "tok"; // Token output file format <basename>.tok
	public static final String ERROR = "err"; // Input file format not in <basename>.tl then <basename>.err
	public static final String ASTDOT = "ast.dot";

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws Exception {
		if (args.length == 1) {
			String fileName = args[0];
			String outFileName;
			Node node = null;
			Scanner scanner = new Scanner(fileName);

			try {
				if (scanner.extension(fileName).equals(PPG583)) {
					node = new Parser(fileName).parse();
					LinkedList<Token> tokens = scanner.scan();
					outFileName = fileName.replaceAll(PPG583, TKDOT);
					Parser.toTokFile(outFileName, tokens);
					SymbolTable table = new SymbolTable(node);
					table.create();
					outFileName = fileName.replaceAll(PPG583, ASTDOT);
					Parser.toAstFile(outFileName, node);
					
				} else {
					System.out.println("File is not in ." + PPG583 + " Format");
					outFileName = fileName.replaceAll(PPG583, ERROR);
					Parser.toErrorFile(outFileName, ERROR);
				}

			} catch (IOException ex) {
				System.err.println(ex.getMessage());
			} catch (ParserError pe) {
				System.err.println("PARSER  ERROR " + pe.getMessage());
			} catch (Exception e) {
				e.printStackTrace();

			}
		}
	}
}
