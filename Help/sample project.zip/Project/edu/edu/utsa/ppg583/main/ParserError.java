package edu.utsa.ppg583.main;

public class ParserError extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4652826950634078231L;

	public ParserError(String expected, Token look) {
		super(look.fileName + ":" + look.lineNumber + " Expected: " + expected + " Found: " + look);
	}

}
