package edu.utsa.ppg583.nodes;

public enum NodeType {
	COMMENTS,
	num, 
	ident, 
	boollit, 
	LP, 
	RP, 
	ASGN,
	SC, 
	MULTIPLICATIVE, 
	ADDITIVE, 
	COMPARE, 
	IF, 
	THEN, 
	ELSE, 
	BEGIN, 
	END, 
	WHILE, 
	DO, 
	program, 
	VAR, 
	AS, 
	INT, 
	BOOL, 
	WRITEINT, 
	READINT, 
	EOF,
	
	/* Node types */
	
	declarations,
	type, 
	statementSequence, statement, 
	assignment, ifStatement, whileStatement, writeInt, elseClause, 
	expression, simpleExpression, term, factor,
	empty,
	
	/* Extra marker types */
	Error,
	None, declaration
	
	}

