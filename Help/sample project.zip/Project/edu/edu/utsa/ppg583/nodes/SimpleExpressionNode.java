package edu.utsa.ppg583.nodes;

import edu.utsa.ppg583.main.*;

/**
 * 
 * @author Harshini
 * <simpleExpression> ::= <term> ADDITIVE <simpleExpression>
 *             | <term>
 * ADDITIVE = "+" | "-"
 *
 */
public class SimpleExpressionNode extends Node {

	public SimpleExpressionNode() {
		super(NodeType.simpleExpression);
	}

	@Override
	public void annotate(SymbolTable table) {
		this.getChildren(0).annotate(table);

		if (this.getChildren().size() == 3) {
			this.getChildren(2).annotate(table);
			this.setErrorOnFalse(this.getChildren(0).expectDataType(NodeType.INT));
			this.setErrorOnFalse(this.getChildren(2).expectDataType(NodeType.INT));

			if (!this.isError()) {
				this.nodeDataType = NodeType.INT;
			}
		} else {
			this.nodeDataType = this.getChildren(0).nodeDataType;
		}

		this.checkChildrenError();
	}

	public TermNode getLeftChildren() {
		return (TermNode) this.getChildren(0);
	}

	public SimpleExpressionNode getRightChildren() {
		return (SimpleExpressionNode) this.getChildren(2);
	}

	public Token getOperator() {
		return (Token) this.getChildren(1);
	}

	@Override
	protected boolean isAstVisible() {
		return this.getChildren().size() == 3;
	}

	@Override
	protected String getAstLabel() {
		return this.getChildren(1).toString();
	}
}
