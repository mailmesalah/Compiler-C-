package edu.utsa.ppg583.nodes;

import edu.utsa.ppg583.main.*;

/**
 * 
 * @author Harshini
 * <term> ::= <factor> MULTIPLICATIVE <term>
 * 					| <factor>
 * 			MULTIPLICATIVE = "*" | "/" | "%"
 *
 */
public class TermNode extends Node {

	public TermNode() {
		super(NodeType.term);
	}

	@Override
	public void annotate(SymbolTable table) {
		this.getChildren().get(0).annotate(table);

		if (this.getChildren().size() == 3) {
			this.getChildren(2).annotate(table);

			this.setErrorOnFalse(this.getChildren(0).expectDataType(NodeType.INT));
			this.setErrorOnFalse(this.getChildren(2).expectDataType(NodeType.INT));

			if (!this.isError()) {
				this.nodeDataType = NodeType.INT;
			}
		} else {
			this.nodeDataType = this.getChildren(0).nodeDataType;
		}

		this.checkChildrenError();
	}

	public FactorNode getLeftChildren() {
		return (FactorNode) this.getChildren(0);
	}

	public TermNode getRightChildren() {
		return (TermNode) this.getChildren(2);
	}

	public Token getOperator() {
		return (Token) this.getChildren(1);
	}

	@Override
	protected boolean isAstVisible() {
		return this.getChildren().size() == 3;
	}

	@Override
	protected String getAstLabel() {
		return this.getChildren(1).toString();
	}
}
