package edu.utsa.ppg583.nodes;

import edu.utsa.ppg583.main.*;

/**
 * 
 * @author Harshini
 * Statement Node
 *
 */
public class StatementNode extends Node {
	public StatementNode() {
		super(NodeType.statement);
	}

	protected StatementNode(NodeType type) {
		super(type);
	}

	@Override
	public void annotate(SymbolTable table) {
		this.getChildren(0).annotate(table);
		this.checkChildrenError();
	}

	public StatementNode getStatement() {
		return (StatementNode) this.getChildren(0);
	}

	public boolean isAssigmentStatement() {
		switch (this.nodeType) {
		case statement:
			return this.getStatement().isAssigmentStatement();
		case assignment:
			return !((AssignmentNode) this).isReadInt();
		default:
			return false;
		}
	}
}
