package edu.utsa.ppg583.nodes;

import java.util.ArrayList;

import edu.utsa.ppg583.main.*;

/**
 * 
 * @author Harshini
 * Statement sequence Node
 *
 */
public class StatementSequenceNode extends Node {
	public StatementSequenceNode() {
		super(NodeType.statementSequence);
	}

	public boolean isEmpty() {
		return this.children.size() == 1 && this.children.get(0) == Node.E;
	}

	@Override
	public void annotate(SymbolTable table) {
		if (!isEmpty()) {
			this.getChildren(0).annotate(table);
			this.getChildren(2).annotate(table);

			this.checkChildrenError();
		}
	}

	@Override
	protected String getAstLabel() {
		return "stmt list";
	}

	@Override
	protected boolean isAstVisible() {
		return !this.isEmpty();
	}

	@Override
	protected ArrayList<StatementNode> getAstChildren() {
		if (this.isEmpty()) {
			return new ArrayList<StatementNode>();
		}

		ArrayList<StatementNode> list = ((StatementSequenceNode) this.getChildren(2)).getAstChildren();

		list.add(0, (StatementNode) this.getChildren(0));

		return list;
	}

	@Override
	protected String getAstAttributes() {
		if (this.isError()) {
			return "shape=box style=solid fontcolor=\"/x11/white\"";
		}

		return "shape=box style=solid";
	}
}
