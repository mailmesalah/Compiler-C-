package edu.utsa.ppg583.nodes;

import edu.utsa.ppg583.main.*;

/**
 * @author Harshini
 * <assignment> ::= ident ASGN <expression>
 *      		|	ident ASGN READINT
 *
 */
public class AssignmentNode extends StatementNode {

	public AssignmentNode() {
		super(NodeType.assignment);
	}

	@Override
	public void annotate(SymbolTable table) {
		table.addReference(this.getAssignedVariable());

		if (this.isReadInt()) {
			this.setErrorOnFalse(this.getAssignedVariable().expectDataType(NodeType.INT));
		} else {
			this.getExpression().annotate(table);

			this.setErrorOnFalse(this.getAssignedVariable().expectDataType(this.getExpression().nodeDataType));
		}

		this.checkChildrenError();
	}

	public Token getAssignedVariable() {
		return (Token) (this.children.get(0));
	}

	public Node getExpression() {
		return (Node) (this.children.get(2));
	}

	public boolean isReadInt() {
		return this.children.get(2) instanceof Token;
	}

	@Override
	protected boolean isAstVisible() {
		return true;
	}

	@Override
	protected String getAstLabel() {
		if (this.isReadInt()) {
			return this.getChildren(1).toString() + " " + this.getChildren(2).toString();
		}

		return this.getChildren(1).toString();
	}
}