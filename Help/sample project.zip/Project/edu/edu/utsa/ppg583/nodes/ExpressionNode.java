package edu.utsa.ppg583.nodes;

import edu.utsa.ppg583.main.*;

/**
 * 
 * @author Harshini
 * <expression> ::= <simpleExpression>
 *        | <simpleExpression> COMPARE <expression>
 * 	COMPARE = "==" | "!=" | "<" | ">" | "<=" | ">=" 
 *
 */
public class ExpressionNode extends Node {
	public ExpressionNode() {
		super(NodeType.expression);
	}

	@Override
	public void annotate(SymbolTable table) {
		this.getLeftChildren().annotate(table);

		if (this.getChildren().size() == 3) {
			this.getRightChildren().annotate(table);

			// Comparison operator COMPARE expects both operand to be same.
			this.setErrorOnFalse(this.getChildren(2).expectDataType(this.getChildren(0).nodeDataType));

			if (!this.isError()) {
				this.nodeDataType = NodeType.BOOL;
			}
		} else {
			this.nodeDataType = this.getLeftChildren().nodeDataType;
		}

		this.checkChildrenError();
	}

	public SimpleExpressionNode getLeftChildren() {
		return (SimpleExpressionNode) this.getChildren(0);
	}

	public ExpressionNode getRightChildren() {
		return (ExpressionNode) this.getChildren(2);
	}

	public Token getOperator() {
		return (Token) this.getChildren(1);
	}

	@Override
	protected boolean isAstVisible() {
		return this.getChildren().size() == 3;
	}

	@Override
	protected String getAstLabel() {
		return this.getChildren(1).toString();
	}

}
