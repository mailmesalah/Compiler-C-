package edu.utsa.ppg583.nodes;

import edu.utsa.ppg583.main.SymbolTable;

/**
 * 
 *@author Harshini
 * <elseClause> ::= ELSE <statementSequence>
 * 				| e
 *
 */
public class ElseClauseNode extends Node {

	public ElseClauseNode() {
		super(NodeType.elseClause);
	}

	public boolean isEmpty() {
		return this.children.size() == 1 && this.children.get(0) == Node.E;
	}

	public StatementSequenceNode getElseStatements() {
		return (StatementSequenceNode) this.getChildren().get(1);
	}

	@Override
	public void annotate(SymbolTable table) {
		if (isEmpty()) {
			return;
		}

		this.getChildren().get(1).annotate(table);
		this.checkChildrenError();
	}

}
