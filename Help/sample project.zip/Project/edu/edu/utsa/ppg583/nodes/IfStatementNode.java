package edu.utsa.ppg583.nodes;

import edu.utsa.ppg583.main.*;

/**
 * 
 * @author Harshini
 * <ifStatement> ::= IF <expression> THEN <statementSequence> <elseClause> END
 *
 */
public class IfStatementNode extends StatementNode {

	public IfStatementNode() {
		super(NodeType.ifStatement);
	}

	public Node getCondition() {
		return (Node) this.getChildren().get(1);
	}

	public StatementSequenceNode getIfStatements() {
		return (StatementSequenceNode) this.getChildren().get(3);
	}

	public ElseClauseNode getElseClause() {
		return (ElseClauseNode) this.getChildren().get(4);
	}

	public boolean hasElseClause() {
		return !this.getElseClause().isEmpty();
	}

	public StatementSequenceNode getElseStatements() {
		return this.getElseClause().getElseStatements();
	}

	public void annotate(SymbolTable table) {
		this.getCondition().annotate(table);

		this.setErrorOnFalse(this.getCondition().expectDataType(NodeType.BOOL));

		this.getIfStatements().annotate(table);
		this.getElseClause().annotate(table);

		this.checkChildrenError();
	}

	@Override
	protected boolean isAstVisible() {
		return true;
	}

	@Override
	protected String getAstLabel() {
		return this.getChildren(0).toString();
	}
}
