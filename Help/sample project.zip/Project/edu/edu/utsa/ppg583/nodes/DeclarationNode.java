package edu.utsa.ppg583.nodes;

import edu.utsa.ppg583.main.*;

/**
 * @author Harshini <declaration> ::= VAR ident AS<type>
 */
public class DeclarationNode extends Node {
	public DeclarationNode() {
		super(NodeType.declaration);
	}
	
	
	@Override
	public void annotate(SymbolTable table) {
		this.setErrorOnFalse(table.declare(this.getVariableName(), this
				.getVariableType().getTypeToken()));
	}

	public Token getVariableName() {
		return ((Token) (this.children.get(1)));
	}

	public TypeNode getVariableType() {
		return (TypeNode) this.children.get(3);
	}

	@Override
	protected boolean isAstVisible() {
		return true;
	}

	@Override
	protected String getAstLabel() {
		String variableNameNode ="";
		String typeNameNode ="";

		switch (this.nodeType) {
		case declaration:
			variableNameNode = this.getVariableName().toString();
			typeNameNode =this.getVariableType().getTypeToken().toString();
			this.children.removeAll(this.children);
			break;
		default:
			break;
		}
		return "decl:'" + variableNameNode + "'";
	}
}
