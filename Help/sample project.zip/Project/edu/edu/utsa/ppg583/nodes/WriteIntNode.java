package edu.utsa.ppg583.nodes;

import edu.utsa.ppg583.main.*;

/**
 * 
 * @author Harshini
 * <writeInt> ::= WRITEINT <expression>
 *
 */
public class WriteIntNode extends StatementNode {

	public WriteIntNode() {
		super(NodeType.writeInt);
	}

	public Node getExpression() {
		return this.getChildren(1);
	}

	@Override
	public void annotate(SymbolTable table) {
		this.getExpression().annotate(table);

		this.setErrorOnFalse(this.getExpression().expectDataType(NodeType.INT));
		this.checkChildrenError();
	}

	@Override
	protected boolean isAstVisible() {
		return true;
	}

	@Override
	protected String getAstLabel() {
		return this.getChildren(0).toString();
	}
}
