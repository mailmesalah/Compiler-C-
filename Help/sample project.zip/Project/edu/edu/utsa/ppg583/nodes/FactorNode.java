package edu.utsa.ppg583.nodes;

import edu.utsa.ppg583.main.*;

/**
 * 
 *  @author Harshini
 * <factor> ::= ident
 * 			| 	num
 * 		    | 	boollit
 * 	        |   LP <expression> RP
 *
 */
public class FactorNode extends Node {

	public FactorNode() {
		super(NodeType.factor);
	}

	@Override
	public void annotate(SymbolTable table) {
		Token first = (Token) this.getChildren().get(0);
		switch (first.getType()) {
		case ident:
			table.addReference(first);
			this.nodeDataType = first.nodeDataType;
			return;

		case num:
			this.nodeDataType = NodeType.INT;
			return;

		case boollit:
			this.nodeDataType = first.nodeDataType;
			return;

		case LP:
			this.getChildren().get(1).annotate(table);
			this.nodeDataType = this.getChildren().get(1).nodeDataType;
			this.checkChildrenError();
			return;
		}
	}

}
