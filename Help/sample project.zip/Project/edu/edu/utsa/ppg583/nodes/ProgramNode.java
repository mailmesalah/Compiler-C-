package edu.utsa.ppg583.nodes;

import edu.utsa.ppg583.main.*;

/**
 * 
 * @author Harshini
 * <program> ::= PROGRAM ident <declarations> BEGIN <statementSequence> END
 *
 */
public class ProgramNode extends Node {
	public ProgramNode() {
		super(NodeType.program);
	}

	public Token getProgramName() {
		return (Token) this.getChildren().get(1);
	}

	public DeclarationsNode getDeclarations() {
		return (DeclarationsNode) this.getChildren().get(1);
	}

	public StatementSequenceNode getStatementSequence() {
		return (StatementSequenceNode) this.getChildren().get(3);
	}

	@Override
	public void annotate(SymbolTable table) {
		this.getDeclarations().annotate(table);
		this.getStatementSequence().annotate(table);
		this.checkChildrenError();
	}

	@Override
	protected boolean isAstVisible() {
		return true;
	}
}
