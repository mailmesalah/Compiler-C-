package edu.utsa.ppg583.nodes;

import java.io.PrintStream;
import java.util.ArrayList;

import edu.utsa.ppg583.main.SymbolTable;
import edu.utsa.ppg583.main.Token;

/**
 * 
 * @author Harshini
 * INT|BOOL
 *
 */
public class Node {

	public static final Node E = new Node(NodeType.empty);

	protected NodeType nodeType;

	public NodeType nodeDataType = NodeType.None;

	protected ArrayList<Node> nodes = new ArrayList<Node>();
	protected ArrayList<Token> tokens = new ArrayList<Token>();
	protected ArrayList<Node> children = new ArrayList<Node>();

	public ArrayList<Node> getChildren() {
		return this.children;
	}

	public Node getChildren(int n) {
		return this.children.get(n);
	}
	
	public Node getSubChildren(int n) {
		return this.children.get(n).children.get(1);
	}

	protected Node(NodeType nodeType) {
		this.nodeType = nodeType;
	}

	public void addNode(Node node) {
		this.nodes.add(node);
		this.children.add(node);
	}

	public void addToken(Token token) {
		this.tokens.add(token);
		this.children.add(token);
	}

	public int toDot(PrintStream stream, int parent, int count) {
		int me = count;

		count++;

		if (this == Node.E) {
			stream.println("\tn" + me + " [label=\"&#949;\", shape=none]");
		} else if (this instanceof Token) {
			stream.println("\tn" + me + " [label=\"" + toString() + "\"]");
		} else if (this instanceof Node) {
			stream.println("\tn" + me + " [shape=ellipse, label=\"" + toString() + "\"]");

			for (Node child : this.getChildren()) {
				count = child.toDot(stream, me, count);
			}
		}

		if (parent != Integer.MIN_VALUE) {
			stream.println("\tn" + parent + " -> " + "n" + me);
		}

		return count;
	}

	/**
	 * This method will go through the syntax tree and mark the type of nodes as
	 * it passes them.
	 * 
	 * @param table
	 *            The symbol table.
	 */
	public void annotate(SymbolTable table) {
		this.checkChildrenError();
	}

	public String toString() {
		return this.nodeType.toString();
	}

	/**
	 * Checks if the data type of this node is the expected type.
	 * 
	 * Example: Condition of a if statement is expected to be boolean
	 * 
	 * @param expectedType
	 *            The expected type of this node.
	 * @return true if the type of this node is the expected type.
	 */
	public boolean expectDataType(NodeType expectedType) {
		if (this.nodeDataType == NodeType.Error || expectedType == NodeType.Error) {
			return false;
		}

		Token place = this.getPlace();

		if (this.nodeDataType != expectedType) {
			String errorString = "TYPE ERROR " + place.fileName + ":" + place.lineNumber + " near " + place.getValue()
					+ ", Expected: " + expectedType + " Observed: " + this.nodeDataType;

			System.err.println(errorString);

			return false;
		}

		return true;
	}

	/**
	 * Used to find the place (file/line number) of a node. file and line number
	 * are stored for only tokens. So if this is node, the first child Token in
	 * the subtree is searched recursively and returned.
	 * 
	 * @return Token first token in this tree.
	 */
	public Token getPlace() {
		if (this instanceof Token) {
			return (Token) this;
		}

		for (Node node : children) {
			if (node instanceof Token) {
				return (Token) node;
			} else {
				Token place = node.getPlace();

				if (place != null) {
					return place;
				}
			}
		}

		return null;
	}

	/**
	 * If any of the children of this node is error, this method will mark this
	 * node as error.
	 */
	public void checkChildrenError() {
		for (Node child : this.getChildren()) {
			if (child.isError()) {
				this.nodeDataType = NodeType.Error;

				return;
			}
		}
	}

	/**
	 * Checks if the data type of this node is error.
	 * 
	 * @return true if this is marked as error.
	 */
	public boolean isError() {
		return this.nodeDataType == NodeType.Error;
	}

	/**
	 * Marks this node as error data type if mark is false.
	 * 
	 * @param mark
	 */
	public void setErrorOnFalse(boolean mark) {
		if (mark == false) {
			this.nodeDataType = NodeType.Error;
		}
	}

	/**
	 * If set, this node is visible on ast graph.
	 * 
	 * Example: A statement list is visible. But statement node is not.
	 * 
	 * @return true if this node is visible on ast.
	 */
	protected boolean isAstVisible() {
		return false;
	}

	/**
	 * The label of this node on the ast graph.
	 * 
	 * @return String the label.
	 */
	protected String getAstLabel() {
		return this.toString();
	}

	/**
	 * The shape/size/color of the ast node.
	 * 
	 * @return String representing .dot file color and shape attribute of this
	 *         node.
	 */
	protected String getAstAttributes() {
		
		return "";
	}

	/**
	 * Gets the children of this node which are visible on ast graph.
	 * 
	 * @return
	 */
	protected ArrayList<? extends Node> getAstChildren() {
		return this.getChildren();
	}

	/**
	 * Prints the current node in ast if it is visible. Then recursively calls
	 * the children to be printed.
	 * 
	 * @param stream
	 *            The output stream
	 * @param parent
	 *            The current parent node number.
	 * @param count
	 *            The next available node number.
	 * @return Updated next available node number.
	 */
	public int toAst(PrintStream stream, int parent, int count) {
		int me = count;
		int oldParent = parent;

		if (this.isAstVisible()) {
			oldParent = parent;
			parent = me;

			count++;

			stream.println("\tn" + me + " [ " + this.getAstAttributes() + " label=\"" + getAstLabel() + "\"];");
		}
		for (Node child : this.getAstChildren()) {
			count = child.toAst(stream, parent, count);
		}

		if (this.isAstVisible() && oldParent != Integer.MIN_VALUE) {
			stream.println("\tn" + oldParent + " -> " + "n" + me + ";");
		}

		return count;
	}
}
