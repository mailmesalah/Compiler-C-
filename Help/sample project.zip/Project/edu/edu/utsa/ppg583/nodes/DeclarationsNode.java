package edu.utsa.ppg583.nodes;

import java.util.ArrayList;

import edu.utsa.ppg583.main.*;

/**
 * 
 * @author Harshini <declarations>::=VARidentAS<type>SC<declarations>
 *         |e
 *
 */
public class DeclarationsNode extends Node {public DeclarationsNode()
{
	super(NodeType.declarations);
}

@Override
public void annotate(SymbolTable table) {
	if( this.isEmpty() )
	{
		return;
	}
	
	this.getDeclaration().annotate(table);
	this.getMoreDeclarations().annotate(table);
	
	this.checkChildrenError();
}

public DeclarationNode getDeclaration()
{
	return (DeclarationNode)this.getChildren(0);
}

public Node getMoreDeclarations()
{
	return ((Node)(this.children.get(2)));	
}

public boolean isEmpty()
{
	return this.children.size() == 1 && this.children.get(0) == Node.E;
}

@Override
protected String getAstAttributes()
{
	if( this.isError() )
	{
		return "shape=box style=solid fontcolor=\"/x11/white\""; 
	}

	return "shape=box style=solid";		
}	

@Override
protected String getAstLabel()
{		
	return "decl list";
}

@Override
protected boolean isAstVisible()
{
	return !this.isEmpty();
}

@Override
protected ArrayList<Node> getAstChildren()
{
	if( this.isEmpty() )
	{
		return new ArrayList<Node>();
	}
	
	ArrayList<Node> list = new ArrayList<Node>();

	list.add(this.getChildren(0));
	list.addAll(this.getChildren(2).getAstChildren());
	
	return list;
}	
}
